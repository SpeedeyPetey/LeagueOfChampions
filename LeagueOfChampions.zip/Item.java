
public class Item {
	
	//declaration of characteristics in an item
	private String name;
	private int price;
	private int hpUpgrade; 
	private int hprUpgrade;
	private int sUpgrade;
	private int arUpgrade;
	private int mrUpgrade;
	private int adUpgrade;
	private int cUpgrade;
	private double lsUpgrade;
	private int apUpgrade; 
	private int rUpgrade;
	
	//initialize the attributes of items (e.g., upgrades of health, damage, resource, etc.)
	public Item (String n, int p, int hp, int hpr, int s, int aR, int mR, int ad, int c, double ls, int ap, int r) {
		
		this.name = n;
		this.price = p; 
		this.hpUpgrade = hp; 
		this.hprUpgrade = hpr;
		this.sUpgrade = s;
		this.arUpgrade = aR;
		this.mrUpgrade = mR;
		this.adUpgrade = ad;
		this.cUpgrade = c;
		this.lsUpgrade = ls;
		this.apUpgrade = ap;
		this.rUpgrade = r;
	}
	
	//get fixed identification of items
	public String getName () {
		
		return this.name;
	}
	public int getPrice () {
		
		return this.price;
	}
	
	//get fixed upgrade values of items 
	public int getHpUpgrade () {//value of upgraded health
		
		return this.hpUpgrade;
	}
	public int getHprUpgrade () {//value of upgraded health regen
		
		return this.hprUpgrade;
	}
	public int getSUpgrade () {//value of upgraded shield
		
		return this.sUpgrade;
	}
	public int getArUpgrade () {//value of upgraded armor 
		
		return this.arUpgrade;
	}
	public int getMrUpgrade () {//value of magic resist
		
		return this.mrUpgrade;
	}
	public int getAdUpgrade () {//value of attack damage
		
		return this.adUpgrade;
	}
	public int getCUpgrade () {//value of upgraded crit chance
		
		return this.cUpgrade;
	}
	public double getLsUpgrade () {//value of upgraded life steal percentage
		
		return this.lsUpgrade;
	}
	public int getApUpgrade () {//value of upgraded ability power
		
		return this.apUpgrade;
	}
	public int getRUpgrade () {//value of resource regen
		
		return this.rUpgrade;
	}
	
}