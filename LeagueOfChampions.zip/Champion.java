public class Champion {
	
	//declaration of characteristics in a champion
	
	//character identity
	private String name;
	private String district;
	private String legacy;
	private String resourceType;
	private boolean type;
	private boolean ownership;
	private int identification;
	private int experience;
	private int price;
	
	//character physical stats
	private int health; 
	private int healthRegen;
	private int shield;
	private int armor; 
	private int magicResist; 	
	private int critChance;
	private int resource;
	private int resourceRegen;
	private double scale;
	
	
	//initialize the attributes of Champion (e.g., health, damage, resource, etc.)
	public Champion (String n, String d, String l, String rt, boolean t, boolean o, int id, int e, int p, int hp, int hpr, int s, int aR, int mR, int c, int r, int rr, double sc) {
		
		this.name = n;
		this.district = d;
		this.legacy = l;
		this.resourceType = rt;
		this.type = t;
		this.ownership = o;
		this.identification = id;
		this.experience = e;
		this.price = p; 
		this.health = hp; 
		this.healthRegen = hpr; 
		this.armor = aR;
		this.shield = s;
		this.magicResist = mR;
		this.critChance = c;
		this.resource = r;
		this.resourceRegen = rr;
		this.scale = sc;
		
	}
	
	//empty initialization for fill champion
	public Champion () {
		
	}
	
	//convert reference value to readable name (toString method)
	public String getName() {
		
		return this.name; 
	}
	
	//get district of champion & display
	public String getDistrict () {
		
		if (this.district.equals("Noxus")) {
			return ("(👹). District: " + this.district);
		}
		else if (this.district.equals("Demacia")) {
			return ("(⚖️). District: " + this.district);
		}
		
		else if (this.district.equals("Ionia")) {
			return ("(🍃). District: " + this.district);
		}
		
		else if (this.district.equals("Bilgewater")) {
			return ("(🌊). District: " + this.district);
		}
		
		else  {
			return ("(💫). District: " + this.district);
		}
		
	}
	
	//get legacy type of champion
	public String getLegacy () {
		
		if (this.legacy.equals("Tank")) {
			return ("(💪). Legacy: " + this.legacy);
		}
		
		else if (this.legacy.equals("Mage")) {
			return ("(🧙‍♂️). Legacy: " + this.legacy);
		}
		
		else if (this.legacy.equals("Marksman")) {
			return ("(🏹). Legacy: " + this.legacy);
		}
		
		else if (this.legacy.equals("Assasin")) {
			return ("(🗡️). Legacy: " + this.legacy);
		}
		
		else {
			return ("(⚒️). Legacy: " + this.legacy);
		}
		
	}
	
	//get resource type of champion
	public String getResourceType () {
		
		return this.resourceType;
	}
	
	//display the resource type & value of champion
	public String displayResource () {
		
		if (this.resourceType.equals("Mana")) {
			return ("(💧). Resource: " + this.resource + " Mana");
		}
		
		else if (this.resourceType.equals ("Energy")) {
			return ("(⚡). Resource: " + this.resource + " Energy");
		}
		
		else {
			return ("(🚫). Resource: No Ability Cost");
		}
	}
	
	//determine champion main attack type
	public String getType () {
		
		if (this.type == true) {
			return ("(👊). Damage Source: Attack Damage");
		}
		
		else {
			return ("(🔮). Damage Source: Ability Power");
		}
	}
	
	//get current ownership status
	public String getOwnership () {
		
		if (this.ownership == true) {
			return ("(🗝️). Ownership: Owned");
		}
		
		else {
			return ("(🔒). Ownership: Locked");
		}
	}
	
	//update ownership status
	public void setOwnership (boolean o) {
					
		this.ownership = o;
	}
	
	//get identification of champion
	public int getId () {
		
		return this.identification;
	}
	
	//get experience of champion
	public int getExperience () {
		
		return this.experience;
	}
	
	public int getLevel () {
		return this.experience / 5; //level up every 3 experience
	}
	
	//update champion experience
	public void setExperience (int e) {
		
		this.experience = e;
	}
	
	//get price of champion
	public int getPrice () {
		
		return this.price;
	}
	
	//get current health of champion
	public int getHealth () {
		
		return this.health;
	}
	
	//update champion health
	public void setHealth (int h) {
		
		this.health = h;
	}
	
	//upgrade health capacity & increase current health according to item
	public void hpUpgrade (Champion summoner, Item upgrade) {
		
		System.out.println("(🖤). Health: " + this.health + " + " + upgrade.getHpUpgrade ());
		
		summoner.setHealth (this.health + upgrade.getHpUpgrade ());
	}
	
	//get health regen of champion
	public int getHealthRegen () {
		
		return this.healthRegen;
	}
	
	//update champion health regeneration
	public void setHealthRegen (int hpr) {
		
		this.healthRegen = hpr;
	}
	
	//regenerate health of champion
	public void regenHealth (Champion summoner) {
		
		summoner.setHealth (this.health + this.healthRegen);
	}
	
	//upgrade health regen according to item
	public void hprUpgrade (Champion summoner, Item upgrade) {
		
		System.out.println ("(💞). Health Regeneration: " + this.healthRegen + " + " + upgrade.getHprUpgrade ());
		
		summoner.setHealthRegen (this.healthRegen + upgrade.getHprUpgrade ());
	}
	
	//get shield of champion
	public int getShield () {
		
		if (this.shield <= 0) { //set shield = 0 if fully broken
			return this.shield = 0;
		}
		
		return this.shield;
	}
	
	//update champion shield
	public void setShield (int s) {
		
		this.shield = s;
	}
	
	//upgrade shield according to item
	public void sUpgrade (Champion summoner, Item upgrade) {
		
		System.out.println ("(🛡️). Shield: " + this.shield + " + " + upgrade.getSUpgrade ());
		
		summoner.setShield (this.shield + upgrade.getSUpgrade ());
	}
	
	//get armor of champion
	public int getArmor () {
		
		return this.armor;
	}
	
	//update champion armor
	public void setArmor (int ar) {
		
		this.armor = ar;
	}
	
	//upgrade armor of champion according to item
	public void arUpgrade (Champion summoner, Item upgrade) {

		System.out.println ("(🎽). Armor: " + this.armor + " + " + upgrade.getArUpgrade ());
		
		summoner.setShield (this.armor + upgrade.getArUpgrade ());
	}
	
	//get magic resist of champion
	public int getMagicResist () {
		
		return this.magicResist;
	}
	
	//update champion magic resist
	public void setMagicResist (int mr) {
		
		this.magicResist = mr;
	}
	
	//upgrade magic resist of champion according to item
	public void mrUpgrade (Champion summoner, Item upgrade) {

		System.out.println ("(👘). Magic Resist: " + this.magicResist + " + " + upgrade.getMrUpgrade ());
		
		summoner.setMagicResist (magicResist + upgrade.getMrUpgrade ());
		
	}
	
	//get crit chance of champion
	public int getCritChance () {
		
		if (this.critChance > 100) { //ensure crit chance don't pass capacity
			this.critChance = 100;
		}
		
		return this.critChance;
	}
	
	//update champion crit chance
	public void setCritChance (int cc) {
		
		this.critChance = cc;
	}
	
	//upgrade crit chance of champion according to item
	public void cUpgrade (Champion summoner, Item upgrade) {

		System.out.println ("(🎯). Crit Chance: " + this.critChance + " + " + upgrade.getCUpgrade ());
		
		summoner.setCritChance (this.critChance + upgrade.getCUpgrade ());
		
	}

	//steal health of opponent & increase current health
	public void stealLife (Champion summoner, int stolenHealth) {
			
		this.health = this.health + stolenHealth;
		System.out.println(summoner.getName () + " Stole " + stolenHealth + " Health due to Life Steal Benefits!\n");
		summoner.setHealth (this.health);
			
	}
	
	//get resource value of champion
	public int getResourceSupply () {
		
		return this.resource;
	}
	
	//update champion resource supply
	public void setResourceSupply (int r) {
		
		this.resource = r;
	}
	
	//get resource regen rate of champion
	public int getResourceRegen () {
		
		return this.resourceRegen;
	}
	
	//update champion resource regeneration
	public void setResourceRegen (int rr) {
		
		this.resourceRegen = rr;
	}
	
	//upgrade resource regen of champion according to item
 	public void rUpgrade (Champion summoner, Item upgrade) {

		System.out.println (summoner.displayResource() + " + " +  upgrade.getCUpgrade () + " " + summoner.getResourceType ());
		
 		summoner.setResourceRegen (this.resourceRegen + upgrade.getRUpgrade ());
	}
 	
 	//reduce resource supply of champion according to ability cost
	public void useResource (Champion summoner, int cost) {
		
		summoner.setResourceSupply (this.resource - cost);
		
	}
	
	//increase shield & regenerate resource in block move
	public void defend (Champion summoner, Abilities blockShield) {
		
		summoner.setShield (this.shield + blockShield.getShield ());
		summoner.setResourceSupply (this.resource + this.resourceRegen);
	}
	
	//get base level scaling of champion
	public double getBaseScale () {
		
		int level = 1 + (this.experience / 5); //level up every 5 experience
		double levelScale = 0.1 * level; //increase scaling per level
		
		this.scale = this.scale + (level - 1) * levelScale;//base scaling based on level
		
		return this.scale;
	}
	
	//update shield & damage after damage
	public void takeDamage (Champion summoner, int damage, int layer) {
		
		if (layer == 1) { //shield is damaged but not broken
			this.shield = this.shield - damage;		
		}	
		
		else if (layer == 2) { //shield is fully broken & leak to health damage
			summoner.setShield (0);
			summoner.setHealth (this.health - damage);
		}
		
		else {//direct attack on health
			summoner.setHealth (this.health - damage);
		}
	}
	
	//champion level up according to minion defeated
	public void levelUp (Champion summoner, int type) {
		
			if (type == 1) { //defeat caster minion
				this.experience = this.experience + 1;
				System.out.println("Experience Gained: " + 1);
			}
		
			else if (type == 2) { //defeat melee minion
				this.experience = this.experience + 2;
				System.out.println("Experience Gained: " + 2);
			}
		
			else if (type == 3) { //defeat cannon minion
				this.experience = this.experience + 3;
				System.out.println("Experience Gained: " + 3);
			}
		
			else { //defeat turret minion
				this.experience = this.experience + 5;
				System.out.println("Experience Gained: " + 5);
			}
			
		summoner.setExperience (this.experience); //update experience
	}
}
