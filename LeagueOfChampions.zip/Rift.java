import java.util.Scanner;

public class Rift {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//starting money to buy champions
		int rp = 450;
		
		//create tank items
		Item warmog = new Item ("Warmog", 500, 500, 100, 0, 0, 0, 0, 0, 0, 0, 0);
		Item thornmail = new Item ("Thornmail", 500, 250, 50, 50, 75, 0, 0, 0, 0, 0, 0);
		Item spiritVisage = new Item ("Spirit Visage", 500, 250, 50, 50, 0, 75, 0, 0, 0, 0, 0);
		Item cloak = new Item ("Cloak", 200, 50, 0, 25, 0, 25, 50, 0, 0, 0, 0);
		Item armorCloth = new Item ("Armor Cloth", 200, 50, 0, 25, 25, 0, 0, 0, 0, 0, 0);
		Item rubyCrystal = new Item ("Ruby Crystal", 200, 100, 25, 0, 0, 0, 0, 0, 0, 0, 0);
		
		//create attack damage items
		Item infinityEdge = new Item ("Infinity Edge", 500, 0, 0, 0, 0, 0, 200, 75, 0, 0, 0);
		Item duskBlade = new Item ("Dusk Blade", 500, 0, 0, 0, 0, 0, 100, 25, 0.5, 0, 0);
		Item bloodThrister = new Item ("Blood Thirster", 200, 0, 0, 0, 0, 0, 25, 0, 0.2, 0, 0);
		Item bfGlove = new Item ("B.F Glove", 200, 0, 0, 0, 0, 0, 25, 20, 0, 0, 0);
		Item longSword = new Item ("Long Sword", 200, 0, 0, 0, 0, 0, 75, 0, 0, 0, 0);
		
		//create ability power items
		Item deathcap = new Item ("Deathcap", 500, 0, 0, 0, 0, 0, 0, 0, 0, 200, 0);
		Item archangelStaff = new Item ("Archangel Staff", 500, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100);
		Item meji = new Item ("Meji", 200, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0);
		Item mote = new Item ("Glowing Mote", 200, 0, 0, 0, 0, 0, 0, 0, 0, 25, 50);
		Item tome = new Item ("Amplifying Tome", 200, 0, 0, 0, 0, 0, 0, 0, 0, 50, 25);
		
		//create resource items
		Item manaCrystal = new Item ("Mana Crystal", 300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50);
		Item energyBomb = new Item ("Energy Bomb", 300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25);
		
		//create Aempyrea attack moves
		Abilities kA =  new Abilities ("Auto Attack", 0, 0, 0, 0, 60, 0.0, 0.0, 0, 0, false, "a");
		Abilities kQ = new Abilities ("Decisive Strike", 1, 0, 0, 0, 60, 0.0, 0.0, 0, 0, false, "q");
		Abilities kW = new Abilities ("Courage", 2, 0, 0, 0, 70, 0.0, 0.0, 0, 0, false, "w");
		Abilities kE = new Abilities ("Judgement", 3, 0, 0, 0, 80, 0.0, 0.0, 0, 0, false, "e");
		Abilities kR = new Abilities ("Demacian Justice", 4, 0, 0, 0, 150, 0.0, 0.0, 0, 0, false, "r");
		Abilities kB =  new Abilities ("Block", 5, 0, 0, 50, 0, 0, 0, 0, 0, false, "b");
		
		//create Wizzy-Bars attack moves
		Abilities bA =  new Abilities ("Auto Attack", 0, 0, 0, 0, 10, 0.0, 0.0, 40, 0, false, "a");
		Abilities bQ = new Abilities ("Baleful Strike", 1, 100, 0, 0, 0, 1.1, 0, 75, 0, false, "q");
		Abilities bW = new Abilities ("Dark Matter", 2, 150, 0, 0, 0, 1.2, 0, 100, 0, false, "w");
		Abilities bE = new Abilities ("Evil Horizon", 3, 200, 0, 0, 0, 1.3, 0, 150, 0, false, "e");
		Abilities bR = new Abilities ("Primordial Burst", 4, 300, 0, 0, 0, 1.5, 0, 200, 0, false, "r");
		Abilities bB =  new Abilities ("Block", 5, 0, 0, 50, 0, 0, 0, 0, 0, false, "b");

		//create Cake attack moves
		Abilities cA =  new Abilities ("Auto Attack", 0, 0, 0, 0, 50, 1.1, 0.05, 0, 0, false, "a");
		Abilities cQ = new Abilities ("Night Hunter", 1, 50, 0, 0, 75, 1.2, 0.1, 0, 0, false, "q");
		Abilities cW = new Abilities ("Silver Bolts", 2, 60, 0, 0, 100, 1.3, 0.2, 0, 0, false, "w");
		Abilities cE = new Abilities ("Condemn", 3, 70, 0, 0, 150, 1.4, 0.3, 0, 0, false, "e");
		Abilities cR = new Abilities ("Final Hour", 4, 100, 0, 0, 200, 1.5, 0.5, 0, 0, false, "r");
		Abilities cB =  new Abilities ("Block", 5, 0, 0, 50, 0, 0, 0, 0, 0, false, "b");
		
		//create Aurelion attack moves
		Abilities aA =  new Abilities ("Auto Attack", 0, 30, 0, 0, 20, 1.0, 0.0, 50, 0, false, "a");
		Abilities aQ = new Abilities ("Breath of Light", 1, 50, 0, 0, 0, 1.1, 0, 75, 0, false, "q");
		Abilities aW = new Abilities ("Astral Flight", 2, 60, 0, 0, 0, 1.0, 0, 125, 0, false, "w");
		Abilities aE = new Abilities ("Singularity", 3, 70, 0, 0, 0, 1.0, 0, 150, 0, false, "e");
		Abilities aR = new Abilities ("Falling Star", 4, 100, 0, 0, 0, 1.0, 0, 250, 0, false, "r");
		Abilities aB =  new Abilities ("Block", 5, 0, 0, 50, 0, 0, 0, 0, 0, false, "b");
		
		//create Fizz attack moves
		Abilities fA =  new Abilities ("Auto Attack", 0, 30, 0, 0, 40, 1.05, 0, 40, 0, false, "a");
		Abilities fQ = new Abilities ("Urchin Strike", 1, 50, 0, 0, 0, 1.1, 0, 100, 0, false, "q");
		Abilities fW = new Abilities ("Seastone Trident", 2, 60, 0, 0, 150, 1.2, 0.3, 0, 0, false, "w");
		Abilities fE = new Abilities ("Playful", 3, 70, 0, 0, 60, 1.3, 0, 100, 60, false, "e");
		Abilities fR = new Abilities ("Chum the Waters", 4, 100, 0, 0, 0, 1.0, 0.5, 215, 0, false, "r");
		Abilities fB =  new Abilities ("Block", 5, 0, 0, 50, 0, 0, 0, 0, 0, false, "b");
		
		//create Galio attack moves
		Abilities gA =  new Abilities ("Auto Attack", 0, 0, 0, 0, 40, 0, 0, 40, 0, false, "a");
		Abilities gQ = new Abilities ("Wind of War", 1, 0, 0, 0, 50, 1.2, 0, 60, 0, false, "q");
		Abilities gW = new Abilities ("Colossal Smash", 2, 0, 0, 0, 80, 1.0, 0.3, 0, 0, false, "w");
		Abilities gE = new Abilities ("Justice Punch", 3, 0, 0, 0, 0, 1.0, 0, 150, 0, false, "e");
		Abilities gR = new Abilities ("Hero Entrance", 4, 0, 0, 0, 100, 1.0, 0, 100, 0, false, "r");
		Abilities gB =  new Abilities ("Block", 5, 0, 0, 50, 0, 0, 0, 0, 0, false, "b");
				
		//create minions attack moves
		Abilities casterA =  new Abilities ("Spell", 0, 0, 0, 0, 10, 1.0, 0, 30, 0, false, "a");
		Abilities meleeA = new Abilities ("Melee Slash", 0, 0, 0, 0, 50, 1.0, 0, 0, 0, false, "a");
		Abilities cannonA =  new Abilities ("Fire Cannon", 0, 0, 0, 0, 50, 1.0, 0, 20, 0, false, "a");
		Abilities turretA =  new Abilities ("Forbiddon Spell Curse", 0, 0, 0, 0, 0, 1.0, 0, 100, 0, false, "a");
		
		//create champions
		Champion kevion = new Champion ("Aempyrea", "Demacia", "Tank", "Resourceless", true, false, 0, 0, 450, 1000, 25, 200, 500, 400, 0, 0, 0, 1.0);
		Champion bars = new Champion ("Wizzy-Bars", "Noxus", "Mage", "Mana", false, false, 1, 0, 450, 800, 20, 0, 20, 20, 0, 500, 50, 1.0);
		Champion cake = new Champion ("Cake", "Ionia", "Marksman", "Energy", false, false, 2, 0, 450, 600, 20, 0, 10, 10, 25, 200, 25, 1.0);
		
		//store created champions, abilities, & items in groups (array)
		Champion [] reborn = {kevion, bars, cake};
		Abilities [][] skills = {{kA, kQ, kW, kE, kR, kB},
								 {bA, bQ, bW, bE, bR, bB},
								 {cA, cQ, cW, cE, cR, cB},
								 {aA, aQ, aW, aE, aR, aB},
								 {fA, fQ, fW, fE, fR, fB},
								 {gA, gQ, gW, gE, gR, gB},
								 {meleeA},
								 {casterA},
								 {cannonA},
								 {turretA}};
		
		Item [][] shop = {{rubyCrystal, armorCloth, cloak, spiritVisage, thornmail, warmog},
						  {longSword, bfGlove, bloodThrister, duskBlade, infinityEdge},
						  {tome, mote, meji, archangelStaff, deathcap},
						  {manaCrystal, energyBomb}};
		
		Scanner scanner = new Scanner (System.in);
		
		gameKnowledge ();
		
		System.out.println("\nIn a world where powerful champions battle for dominance, the Rift stands as the ultimate proving ground. \nLegends are forged through strategy, skill, and relentless combat. \nWill you rise as a champion, mastering the battlefield, or fall among the forgotten?\nThe choice is yours—enter the Rift and claim your destiny!\n");
		System.out.println("It is strongly recommended to play in full screen for the full experience!\n");
		System.out.println("Enter the Rift: ['y']\tExit the Rift: ['n']");

		String game = scanner.nextLine ();
		
		//ensure valid input to start or end game
		while (!game.equals("y") && !game.equals("n")) {
			System.out.println ("Invalid Input...\tEnter the Rift: ['y']\tExit the Rift: ['n']");
			game = scanner.nextLine ();
		}
		
		if (game.equals("y")) {
			
		
			//end game if opponent is defeated (win)
			if (selectChampion (rp, reborn, skills, shop) == true) {
				
				System.out.println("\nYou are Victorious!\n");
				
			}
			
			//end game if player is defeated (lose)
			else {
				
			}
				System.out.println ("\nYou Succumbed to Death..!\n");
		}
		
		System.out.println ("Thanks for Playing!\t\tVisual Display Inspired by: Chan Dao");
	}
	
	public static void gameKnowledge () {
		
		//display introductory hook about the game
		System.out.println("WELCOME TO THE LEAGUE OF CHAMPIONS RULE BOOK!/nThe Rift isn’t big enough anymore—now it’s one-on-one, strategic itemization, fists flying, abilities clashing!\nStep into the ultimate street fight, where combos, counters, and chaos decide who stands victorious!\n");
		
		//display information about game format
		System.out.println("Game Layout: \n\t1.League of Champions is a single-player game where the player competes against AI-controlled champions in strategic combat.");
		System.out.println("\t\t2.The game operates on a turn-based system. Each round consists of two turns: one for the player and one for the opponent. The player will first select their actions, followed by the opponent’s turn. Once both the player and the opponent have completed their respective actions, the round is considered a full turn.");
		System.out.println("\t\t3.Champion Selection Phase: During the Champion Selection Phase, players can inspect the available starting champions, viewing their icons and stats. They can choose to lock in a champion to claim ownership or return to explore other options before making a final decision.");
		System.out.println("\t\t4.Battle Phase: During the Battle Phase, players can choose to attack their opponent directly, farm minions to earn gold, purchase items, or view their own and their opponent's current stats.");
		System.out.println("\t\t5.After each move is made, a description or detail of the round will be provided");
		System.out.println("\t\t6.Objective: The objective of the game is to defeat your opponent before they defeat you!");
		
		//display information about game manual
		System.out.println ("Game Manual: \n\t1. Players interact with the game by selecting options presented within square brackets []");
		System.out.println ("\t\t2. The game ends when either the player's or the opponent's health reaches 0.");
		
		//explain unique aspect of the game in detail
		System.out.println ("\n\t2. Navigation Controls");
		System.out.println ("\t\t- Select a champion by entering its corresponding number.\"");
		System.out.println ("\t\t- View the game book anytime by selecting ['i'] at the start of a round.");
		System.out.println ("\t\t- Attack ['a'], block ['b'], or farm minions ['f'].");
		System.out.println ("\t\t- Purchase items with ['p'], inspect them with ['i'], and confirm purchase with ['b'].");
		System.out.println ("\t\t- Check your stats ['s'] or your opponent’s stats ['o'] after each turn.");
		
		//explain common terms throughout the game
		System.out.println ("\n\t2. Terminology: ");
		System.out.println("\t\tInspection: Viewing the stats of a Champion, Ability, or Item.");
		System.out.println ("\t\tFarm: Gaining gold and experience by defeating minions.");
		System.out.println ("\t\tBuild: A specific category of items.");
		
		//display information about specific game features
		System.out.println ("Game Features: \n\t1. Champion Stats:");
		
		//explanation on champion stats
		System.out.println("\tDistrict: Reflects its origin lore and do not influences gameplay.");
		System.out.println("\t\tLegacy: Defines a champion's playstyle.");
		System.out.println("\t\tResource Type: Determines the resource a player uses based on their abilities.");
		System.out.println("\t\tChampion Type: Defines the champion's primary source of attack.");
		System.out.println("\t\tExperience Points: Contribute to leveling up, requiring 5 experience for each level.");
		System.out.println("\t\tHealth: Represents a champion's lifespan; if it reaches 0, the champion dies.");
		System.out.println("\t\tHealth Regeneration: The health regenerated each round based on champion's stats.");
		System.out.println("\t\tShield: Acts as an additional layer of health.");
		System.out.println("\t\tArmor: Reduces the damage from physical attacks.");
		System.out.println("\t\tMagic Resist: Mitigates the effects of incoming ability power.");
		System.out.println("\t\tCrit Chance: Probability of landing a critical strike, significantly boosting damage.");
		System.out.println("\t\tLife Steal: Allows a champion to regain a percentage of the opponent's health when dealing damage.");
		System.out.println("\t\tResource Regeneration: The amount of resource regained when a champion blocks and charges up.");
		System.out.println("\t\tAttack Damage: The raw physical damage dealt by a champion.");
		System.out.println("\t\tAbility Power: Determines the damage of a champion's abilities.");
		System.out.println("\t\tScale: Represents the increase in adaptive force (attack damage + ability power) per level.");
		
		//explain the battle opponent phase
		System.out.println ("\n\t3. Attack & Block:");
		System.out.println("\t\t- Attack ['a']: Choose an ability to use, considering its initial resource cost and cooldown.");
		System.out.println("\t\t- Abilities follow a power hierarchy, with 'q' being the weakest and 'r' as the ultimate.");
		System.out.println("\t\t- Be mindful of cooldowns and resource supply before using abilities.");
		System.out.println("\t\t- Block ['b']: Increases natural resource regeneration and shield.");
		System.out.println("\t\t- Blocking helps recharge resources if needed for abilities.");
		System.out.println("\t\t- Attacks can target both minions and opponents, but blocking is only available in non-farming phases.");
		
		//explain the farm phase
		System.out.println("\n\t4. Farming:");
		System.out.println("\t\t- Farm ['f']: Choose an ability to attack minions.");
		System.out.println("\t\t- Levels 0-5: Only melee and caster minions spawn.");
		System.out.println("\t\t\t  * Caster minions: 50 gold, 1 experience.");
		System.out.println("\t\t  * Melee minions: 100 gold, 2 experience.");
		System.out.println("\t\t- Level 6+: Only cannon and turret minions spawn.");
		System.out.println("\t\t\t  * Cannon minions: 250 gold, 3 experience.");
		System.out.println("\t\t\t  * Turret minions: 500 gold, 5 experience.");
		System.out.println("\t\t- Minions retaliate when attacked.");
		System.out.println("\t\t- Blocking is not allowed during farming.");
		System.out.println("\t\t- Players must defeat a minion before starting the next round.");
		System.out.println("\t\t- After a minion is defeated, the opponent gets an opportunity to attack before the round ends.");
		
		//explain the buy phase
		System.out.println("\n\t5. Shopping & Items:");
		System.out.println("\t\t- Buy ['p']: Choose to purchase or inspect an item.");
		System.out.println("\t\t- Inspect ['i'] or Buy ['b']: Select a build category by entering its corresponding number.");
		System.out.println("\t\t- Inspecting an item reveals its stat upgrades.");
		System.out.println("\t\t- After inspection, players can buy the item, browse more, or return to play.");
		System.out.println("\t\t- Ensure sufficient gold before purchasing an item.");
		System.out.println("\t\t- Purchased items grant immediate stat upgrades.");
		System.out.println("\t\t- No limit on the number of items a player can buy; stats stack cumulatively.");
		
	}
	
	//choose the fighting champion
	public static boolean selectChampion (int rp, Champion [] reborn, Abilities [][] skills, Item [][] shop) {
		
		//display money owned
		System.out.println("Inspect a Champion for Battle!");
		System.out.println("RP: " + rp);
		
		//display champion options
		for (int i = 0; i < reborn.length; i++) {
			System.out.print("[" + reborn [i].getId () + "]. " + reborn [i].getName () + ": " + reborn [i].getPrice() + " RP\t\t");
		}
		
		int gold = 0; //set starting gold
		
		System.out.print("\n");
		Scanner scanner = new Scanner (System.in);
		
		int choice = scanner.nextInt ();
		
		//ensure valid champion selection
		while (choice != 0 && choice != 1 && choice != 2) {
			System.out.println("Invalid Input!");
			
			for (int i = 0; i < reborn.length; i++) {
				System.out.print("[" + reborn [i].getId () + "]. " + reborn [i].getName () + ": " + reborn [i].getPrice() + " RP\t\t");
			}
			
			System.out.print("\n");
			choice = scanner.nextInt ();
			
		}
		
		Champion nemesis = opponent (); //get opponent
		
		showChampion (reborn [choice], skills); //display champion stats
		
		//ensure user's confirmation of champion
		if (lockIn (rp, reborn [choice], reborn, skills, shop, choice)) {
			
			return arena (reborn [choice], nemesis, skills, shop, gold);
		}
			
		//ensure user's choice is valid
		else {
			selectChampion (rp, reborn, skills, shop);
		}
		
		return false;
	}
	
	//ensure user's confirmation of champion
	public static boolean lockIn (int rp, Champion blue, Champion [] reborn, Abilities [][] skills, Item [][] shop, int c) {
		System.out.println("Lock in Champion ['l'] or Return to Selection ['r']");
		
		Scanner scanner = new Scanner (System.in);
		String lock = scanner.nextLine ();
		
		while (!lock.equals("l") && !lock.equals("r")) {
			System.out.println("Invalid Input!\tLock in Champion ['l'] or Return to Selection ['r']");
			lock = scanner.nextLine ();
		}
		
		//enter battle with purchased champion
		if (lock.equals("l") && blue.getPrice () <= rp) {
			blue.setOwnership(true);
			rp = rp - blue.getPrice (); //reduce rp according to champion cost
			return true;
		}
		
		//return to champion selection page
		else if (lock.equals("r")){
			return (selectChampion (rp, reborn, skills, shop));
			
		}
		
		//ensure sufficient rp to buy champion 
		else {
			System.out.println ("Insufficient RP!\nRP: " + rp + "\tCost: " + blue.getPrice ());
			return (selectChampion (rp, reborn, skills, shop));
		}
	}
	
	//generate opponent randomly
	public static Champion opponent () {
			
		//create opponents
		Champion aurelion = new Champion ("Aurelion", "Celestial Realm", "Mage", "Energy", false, false, 3, 10, 0, 1000, 50, 200, 50, 50, 25, 200, 50, 2.0);
		
		Champion fizz = new Champion ("Fizz", "Bilgewater", "Assasin", "Mana", true, false, 4, 10, 0, 1100, 50, 100, 30, 40, 25, 500, 50, 2.0);
		
		Champion galio = new Champion ("Galio", "Demacia", "Juggernaut", "Resourceless", false, false, 5, 10, 0, 1200, 50, 200, 60, 60, 25, 0, 0, 2.0);

		//randomly select created opponents
		int challenger = (int)(Math.random() * 3) + 1;
		
		if (challenger == 1) {
			return (aurelion);
		}
		
		else if (challenger == 2) {
			return (fizz);
		}
		
		else {
			return (galio);
		}
	}
	
	//display stats of the champion
	public static void showChampion (Champion summoner, Abilities [][] skills) {
		
		//show champion icon
		if (summoner.getName ().equals("Aempyrea")) { //show Ampyrea icon
			System.out.println ("\r\n"
					+ "███████████▓████████████████████████████████████████████████\r\n"
					+ "██████▓▓███▒████████████████████████████████████████████████\r\n"
					+ "█████▓▓▓▓█▓▓████████████████████████████████████████████████\r\n"
					+ "████▓▓▓▓▓▓▓░████████████████████████████████████████████████\r\n"
					+ "████▓▓▓▓▓▓▓▒▓██▓████████████████████████████████████████████\r\n"
					+ "████▓▓▓▓▓██▓▓██▓████████████████████████████████████████████\r\n"
					+ "████▓▓▓▓▓██▓▒▓▓████▓██████▓▓▓█████████▒▒▓███████████████████\r\n"
					+ "████▓▓▓█████░▓███▓▓███▓▓▓▓▒▓█▓████▓▓▒░░▓██▓▓████████████████\r\n"
					+ "████▓▓█████▓░▒▓██▓▓█▓▓▓▓▒▒▒▒▒███▓▓▒░░░░██▓▒▓███▓████████████\r\n"
					+ "████████████░░▒▓▓██▓▓▒▒░▒▒▒▒██▓▓▒░░░░░▒▓▒░▓▓██▓▒▓██████▓████\r\n"
					+ "████████████░░▓▓▓████▓▒▒▒▒▒▓▓▒░░░░░░░▒▓▒▒▓▓▓▓▓▒▓▓█▓█████▓███\r\n"
					+ "████████████▒░▒▓▓▓█▓██▓▒▒▒▒▒░░▒▒▒▒░▒▒▓████▓▓▓▒▒▓█▓██████▓███\r\n"
					+ "█████████████░▒▒▓▓▓▓▓▓██▒▒▒░░▒▒░▒▒████████▓▒▒▒▓▓▓▓███▓▓█████\r\n"
					+ "███████▓█████░▒▒▒▒▒▒▒░▒▓▓▓▒░▒▓▓█▓▓▓▓▓▓▓▓▓▒▒▒▒▓▓▓▓██████▓████\r\n"
					+ "████▓▓▓██████▓▒▓▒▒▒▒▒▒▒▒▓▓░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓█████▓██████\r\n"
					+ "████▓▓███████▓░▓▒▒▒▒▒░▒▒▓▒░░░░░▒▒░░░░░░░▒▒▒▒▓▓▓▓██▓▓████████\r\n"
					+ "████▓▓▓▓▓████▒░▒▒▒▒▒▒▒▒▒▓▒░░░░▒▒▒▒▒░░▒▒▒▒▒▒▓▓▓▓▓█▓██████████\r\n"
					+ "████▓▓▓▓█████▒░▒▒▒▒▒▒▒▒▓░▒░░░░▒▒░▒▒▒▒▒▒▒▒▒▓▓▓▓▓█████████████\r\n"
					+ "███▓▓▓▓▓█████░▒░▒▒▒▒▒▒▒▒▓░░▒▓▓▒░░░░░▒▒▒▒▒▒▓▒▒▓██████████████\r\n"
					+ "███▓▓▓███████▓▓▒▒▒▒▒▒▓▒▒▒▓▒▒▒░░░░░░░▒▒▒▒▒▒▒▒▒▓██████████████\r\n"
					+ "███▓▓█████████▓▓░▒▒▒▓██▓▒▒▒▒▒▒▒▒▒░░░▒▒▒▒▒▒▒▒▒███████████████\r\n"
					+ "███████████████▓▒▒▒▒▓▒▓██▓▓▒▓▓▓███▓▒▒▒░▒▒▒▒▓████████████████\r\n"
					+ "████████████████▓░▒▒▓▒▒███▓██████▓▓▓▒▒▒▒▒▒▓█████████████████\r\n"
					+ "█████████████████▒▒▒▒▓▒░▒▓▓▓▓▓▓▒▒▒█▒▒▒▒▓▓█████████████▓█████\r\n"
					+ "█████▓▓██████████▓▒▒▒▒▓▒░░░░░░░░▓▒░▒▒▓▓██████████▓▓▒▒▒▒▓▓▓██\r\n"
					+ "█████▓▓███████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓████████▓▓▒▒▒▒▒▒▒▒▒▓▓██\r\n"
					+ "█████▓████████████▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓█████▓▓▓▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓██\r\n"
					+ "█████████████████████▓▒▒▒▒▒▒▒▒▒▓████▓▓▒▒▒▒▒▓▓▒▒▒▒▒▒▒▒▒▒▒▓▓██\r\n"
					+ "███▓▓▓▓██████████████████▓▓▓▓▓█▓▒▒▒▒▒▒▒▒░░░░░▒▓▓▒▒░░░░░░░▒██\r\n"
					+ "███▓▓▓▓▓▓▓▓▓▓▓▓▓▓██████████▓▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░▒░░░░░░░░▒▓█\r\n"
					+ "███████████████████████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▒▒▓▓▓▒▒▒▒▒▓▓██\r\n"
					+ "████████████████████████████████████████████████████████████\r\n");
			
			System.out.println ("\nAempyrea, a formidable Demacian warrior, was forged in the fires of relentless battle, embodying unshakable resilience. \nAs a Tank, he excels in absorbing damage and protecting his allies, standing firm against even the fiercest foes. \nBeing Resourceless, Aempyrea relies solely on cooldowns rather than mana or energy, ensuring he can always engage without constraints.\n\n");
		}
		
		else if (summoner.getName ().equals("Wizzy-Bars")) { //show Wizzy-Bars icon
			
			System.out.print("\r\n"
					+ "██████████████████████████████████████████▓▓▓█████▓▓▓█▓▓▓▓▓▓\r\n"
					+ "██▓▓▓▓████████████████▓█████▓▓▓▓████████▓█▓▓▓▓▓▓▓▓▓▓▓▓▓█▓▓▓▓\r\n"
					+ "███▓▓▓█▓███████████▓██▓▓▓▓▓▓▓▓▓▓▓███████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▓▓▓▓▓\r\n"
					+ "█████▓▓██████████████████▓▓▓▒▒▒▒▓███████▓▓▓▓▓▓▓▓▓█▓▓▓▓▒▒▓▓█▓\r\n"
					+ "█████████▓▓▓▓▓▓▓▓▓▓███████▓▓▒▒▒▓▓███████▓▓▓▓▓▓▓▓▓▓█▓▓▓▓▓▓▓▓█\r\n"
					+ "███▓██▓▓▓▓▓▓▓▓▓▒▒▒████████▓▓▓▓▓▓▓▓███████▓▓▓▓▓▓▓▓▓█▓▓▓▓▓▓▓▓▓\r\n"
					+ "██▓▓▒▓▓▓▓▓▓▒▒▒▒▒▒▒▓█████████▓▒▓▓▓▒▓███████▓▓▓▓██████▓▓▓▓▓▓▓▓\r\n"
					+ "▓▓▓██▒▒▓▓▓▓▓▓▓▓▓▓▓▓██████████████▓▒▓▓▓▓█████████████▓▓▓▒▒▓▓▓\r\n"
					+ "▓▓▓██▓░▒▓▓▓▓▓▓▓▓▓▓▓▓█████▓███████████████████████████▓▒▓▓▓▓▓\r\n"
					+ "▓▒▓██▓▓▒▒▓▓▓▓▓▓▓▓▓▓▓█████████████████████████████████▓▒▒▒▓▓▓\r\n"
					+ "█████▓▒▒▒░▓▓▓▓▓▓▓▓▓███████████████████████████████████▓▒▒▒▒▒\r\n"
					+ "▒████████▒░░░▒▒▓▓▓███████████████████████████████████▓▓██▓▓▓\r\n"
					+ "░░▓▓▓███████▒░░▒▓█████████████████▓███████▓▓▓▓▓██████▓▓▓▓▓▒▒\r\n"
					+ "▒▒░▒▓░▒▓▓▓██▓░░░░▒▓█████████▓▒▓▓▓▓█████████▓▓████▓███▓▓▒▒▒█▓\r\n"
					+ "▓▓▓▓▓▓░░░▓▒███░░░░░▒█████████▒░░▒████████▓▓▓██████▓██▓▓▒▓▓▓▓\r\n"
					+ "██████▓▓▓▓█▓███▒░░░░░▒▓████████████████▒░░▒▓▓████▓▓██▓▓█▓███\r\n"
					+ "██▓███████████████▓▓░░░░▒▓██████████████▓▓███████▓████▓▓▓███\r\n"
					+ "███████▓█████████████▓▒░▒▒░░▒▒▓▓████████████████▓██▓▓█▓▓▓▓▓▓\r\n"
					+ "█████████████████▓███▓▓▓▒▒▓▓██▓▓▒▒▓▓███████████▓██████▓▒▓█▓▓\r\n"
					+ "████████████████▓▓██▓█████████████▒▓▒▒▒▒▒▒▒▓██▓██▓█████▓██▓█\r\n"
					+ "████████████████████████▓▓███▓█████▓▓▓▓▓▓▓▓▓▓▒▒▓███████▓██▓▓\r\n"
					+ "████████████████████████▓▓████▓▓▓▓█▓████▓█▓▓▓▓▓▓▓▓█████████▒\r\n"
					+ "████████████████████▓▓▓███▓▓▒▒▒░▒▓█▓███████▓▓▓▓▓▓███████▓▒▒▓\r\n"
					+ "██████████████████████████▓▓▓▓▓▓▓▒▒▓███████▓▓▓▓▓▓▓▓▓▒▒▓▓▒▒▒█\r\n"
					+ "█████████████████████████████████▓▓█▓████████▓██████▓░░▒▒▒▓█\r\n"
					+ "█████████████████████████████▓▓▓█▓▓▒▒▓████████▓██████▓░▒▒▒▓▓\r\n"
					+ "████████████████████████████▓▓▓▒▒▓▓▒░░▒▓██████▓███████▓▒▒▒▓█\r\n"
					+ "█████████████████████████████▓▓██▓▒▒▒▒▓▒▒▓█████████████▓████\r\n"
					+ "███████████████████████▓██████████▓▒▒▒▒▒▒▒▓█████████████████\r\n"
					+ "██████████████████████████████████▓▒▒▒▓▓▓▒▒▒████████████████\r\n"
					+ "████████████████████▓██████████▓▓▓▓▒▒▓▓████▓▓███████████████\r\n"
					+ "██████████████████████████████████▓▓▓███████▓███████████████\r\n");
			
			System.out.print("\nWizzy-Bars, a cunning Noxian Mage, wields immense ability power, bending arcane forces to obliterate his foes. \nAs a Mage, he excels in dealing high burst damage from a distance, relying on precise spell rotations to dominate the battlefield. \nFueled by Mana, he must strategically manage his resource to sustain his powerful magic and outlast his enemies.\n\n");
		}
		
		
		else if (summoner.getName ().equals("Cake")) { //show Cake icon
			
			System.out.print("\r\n"
					+ "████████████████████████████████████████████████████████████\r\n"
					+ "████████████████████████████████████████████████████████████\r\n"
					+ "██████▓███████▓▓████████████████████████████████████████████\r\n"
					+ "██████▓██████▓▒▒▒███████▓▓███████▓▓▓▓▓▓█████████████████████\r\n"
					+ "██████████████▓▒▒██████▒▒▓████████▓▓▓▓▓█████████████████████\r\n"
					+ "███████████████▒▓▓▓███▓▒▓█▓▓███████████▓▓▒▓▓▓▓▒▓█▓▒▓▓▓▓█████\r\n"
					+ "███████████████▓████▓▒▓█▓██▓▓▓▓██▓▓▓▒▒▒▒▒▒░░▒░▒▒▓▒▒▒▒▒▓█████\r\n"
					+ "██████████████████▓██████▓██▓▓▓▓▓▓▓▒▒▒▒▒░░░░░░░▓▒▒░░▒▒▓▓████\r\n"
					+ "██████████████████▓██████████▓▓▓▓▓▓▒▒▒▒▒▒▒▒░░▒▓▒░░░░▒▒▓▓████\r\n"
					+ "█████████████████▓▓███▓▓███████▓▓▓▓▓▒▒▒▒▒▓▒▓▓▓░░░░░░▒▒▓▓▓███\r\n"
					+ "████████████████▓▓█▓▓▓▓████▓████▓▓▓▓▒▒▒▒▒▓▓▓░░░░░░░▒▒▒▓▓▓███\r\n"
					+ "████████████████▒▓█▓▓██▓▓███▓▓██▓▒▒▒▒▒▓▓▓▒░░░░░░░▒▒▒▓▓▒▒▓███\r\n"
					+ "████████████████▒▓▓▓▓██████████▓▓▓▓▓▓▒▒▒▒▒▒▓▓▓▓▓█▓▒▒▒▓▓▒▓███\r\n"
					+ "████████████████▓▓▓▓▓▓█████████████▓▓▓▓▓███████▓▓▒▒▒▒▒▒▓▓███\r\n"
					+ "████████████████▓▓▓▓▓▓▓▓██████████████▓▓▓████▓▓▓▓▓▓▓▓▓▒▒▓███\r\n"
					+ "████████████████▓▓▓▓▓▓▒▒▒▒▒▓▓▓▓▓▓▓▓████▓█▓▓▓▓▓▓███▓▓▓▒██████\r\n"
					+ "███████████▓████▓▓▓▓▓▒▒▒▒▒▓▓▓▓▓▓▒░░▓▓███▓▓▓▓▓▓▓▓▓▓▓▒▒▓▓▓████\r\n"
					+ "███████████▓▓██▓▓▓▓▓▓▒▒▒▒▓▓▓▓▓▓▒░░░░▒▓▓▓██▓▓▓▓▓▓▓▓▓▓▒░░▒▓███\r\n"
					+ "███████████▓▓██▓▓▓▓▓▓▓▒▒▓▓▓▓▓▓▒░░▒░░░░▒▓▓▓▓▓▓▒▒▒▒▒▒▒▒░░▓████\r\n"
					+ "███████████▓▓███▓█▓▓▓▓▒▒▓███▓▒░░░░░░░░░░░░░░░░░░░░▒▒░░▓▓▓███\r\n"
					+ "████████████▓██████▓▓▓▒▒▓▓███▓▒▒▓▓▒░░░░░░░░░░░░░░░░░░▒▒▒████\r\n"
					+ "████████████▓▓█████▓▓▓▒▒▒▓███▓▓▓▓▒░░░░░░░░░░░░░░░░░░░▒▓█████\r\n"
					+ "█████████████▓█████████████▓▓▓▒▒░░░░░░░░░░░░░░░░░▒▒▓████████\r\n"
					+ "█████████████▓██████▓████████▓▓▒▒░░░░░░▒▒░░░░░░░▓███████████\r\n"
					+ "████████████████████████▓██▓███▓▒▒▒▒▒▒▒░░░░░░░▓▓████████████\r\n"
					+ "██████████████████████████▓▓▓▓▓█▓▓▒▒▒▒░░░░░░▒▓██▓▓██████████\r\n"
					+ "█████████████████████▓▓▓▓▓██▓▓▒▒▒▒▒▒▒░░░░░░▓████████████████\r\n"
					+ "██████████████████████▓▓▒▒▒▓▓▓▓▓▒▒▒▒▒▒▒▒░▒▓█████████████████\r\n"
					+ "███████████████████████▓▓▓▓▓▓▓▓▒▒▓▓▓▓▒░░▓▓▓▓████████████████\r\n"
					+ "██████████████████████████████████▓▓▒▒▒▓█▓▓▓▓▓██████████████\r\n"
					+ "███████████████████████████████████▓▓▓██████████████████████\r\n"
					+ "████████████████████████████████████████████████████████████\r\n");
			
			System.out.print("\nCake, a swift and disciplined Ionian Marksman, channels Energy to deliver rapid and precise ranged attacks. \nAs a Marksman, she relies on agility and sustained damage, whittling down enemies with relentless precision. \nWith a limited but regenerating Energy pool, she must carefully time her abilities to maximize her offensive potential without running dry in critical moments.\n\n");
			
		}
		
		else if (summoner.getName ().equals("Aurelion")) { //show Aurelion icon
	
			System.out.print("\r\n"
					+ "███████████████████████████▓███▓▓▓▓████▓▓▓▓▓▓▓██▓▓▓▓▓▓▓▓████\r\n"
					+ "███▓▓███████████████████▓▓▓██████▓█▓█████▓▓█▓▓▓█████▓███████\r\n"
					+ "█████▓▓████▓████████████████████████▓██████▓▓▓▒▓████████████\r\n"
					+ "████████▓████▓██▓██████████▓████████████████▓▓▓▓▓▓██████████\r\n"
					+ "████████████████▓▓▓▓▓▓█████▓████████████▓▓▓█▓▓█▓▒▓██████████\r\n"
					+ "█████████████████▓▓█████▓████▓████▓▓███▓█▓▓▓▓▓▓▓▒▓███▓██████\r\n"
					+ "███████████████████████████▓███████▓▓██████▓▓▓▓▓▒▓████▓█████\r\n"
					+ "█████████████████████████▓███▓▓▓█████████████▓▓▓▓▓██▓█▓▓████\r\n"
					+ "█████████████▓▓▓▓▒▓██████▓▓███████████████████▓▓▓█▓▓█▓██████\r\n"
					+ "████████▓▓██████▓▓▒▒░▒▓██▓▓▒▓███████████████▓▒██▓█▒█▒▓██████\r\n"
					+ "███████▓███████████▓▒░░▒▓▒▒▒▒▓▓██▓▒▒▓███▓██▓▒░▓████▓▒███████\r\n"
					+ "███████████████████▓▓▒▒▒░░▓████▓▓▓██▓██████▓▒░▒▓▓█▓▒▓███████\r\n"
					+ "█████████████▓▒▓███▓▒▒▒▒▒▓█████▒▓█▓▒█▓▒██▓▓██▓▒▓▓██▓████████\r\n"
					+ "██████▓███████▓▓▓█▓▓▒▒▒▒▓████▓▓▓░▒█▒██▓▒▒▓█▓██▓▒▓█▓█████████\r\n"
					+ "██████▓█████▓▓▒▒▓▓███████████▓▓▓░▒█▓▒██▓▓▒▒██▓▓▓████████████\r\n"
					+ "███████▓████▓▓▓▒▓████████████▓▓▒░▓▓▓▒▒▓▓▓▓▒░░▒▒▒████████████\r\n"
					+ "████████▓███▓▓▓▓▒▒▒▒▒█████████▓▒▒▒▓▓▒▒▒▓██▓▓▓▓▒▓████████████\r\n"
					+ "████████▓██▓████▓▓▓▓▓▓▒███████████▓▒▒▓▓█████▓███████████████\r\n"
					+ "████████▓▓██▓█▓█▓▓█▓▓▓▓▓▓████████▓▓▓█▓▒▓▓▓▒▓▓▒██████████████\r\n"
					+ "█████████▓██▓▓█████▓▓▓▓██▓▓██████████▓▓▓▒▒▓░░███████████████\r\n"
					+ "████▓████▓▓█████████▓▓█████▒▓███████▓▓▓▓▒░▓░▓███████████████\r\n"
					+ "███▓█████▓▓███▓▓▓▓▓▓▓▓▓████▓▓███████▓▓▓▓▓▓▒▒████████████████\r\n"
					+ "██▓███▓▒▓▓▒████▒▓▓▓▓▓▓▓███████▓███▓██▓▓█▓▓▒█████████████████\r\n"
					+ "█▓███████▓▓████▓▓▓▒░▒▓▓█████████▓██████▓▒▓██████████████████\r\n"
					+ "██████████▓█████▓█▓▓▓▓▓██████████▓█████▒░███████████████████\r\n"
					+ "█████████████████████████████▓█████▓███░████████████████████\r\n"
					+ "██████████████████████████████▓▓▓█████▓▓████████████████████\r\n"
					+ "████████████████████████████████▒▒▓▓████████████████████████\r\n"
					+ "████████████████████████████████████▓████████▓██████████████\r\n"
					+ "██████████████████████████████████████████████████▒▓████████\r\n"
					+ "██████████████████████████████▓████████████████████████▓▓███\r\n");
			
			
			System.out.println("\nAurelion, a celestial being from the Celestial Realm, commands the vast power of Energy to shape the cosmos with her spells. \nAs a Mage, she harnesses high ability power, devastating enemies with her immense magical control from a distance. \nWith a steady flow of Energy, Aurelion must strategically manage her resources to unleash her full potential, bending the very fabric of reality to her will.\n\n");
			
		}
		
		else if (summoner.getName ().equals("Fizz")) { //show Fizz icon
			
			System.out.print("\r\n"
					+ "████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓███\r\n"
					+ "██▓▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒▒▒▓▓▓▒▒░░░░▒▓█\r\n"
					+ "██▓▒░░░░░░░░░░░░░░░░░░░░░░░▒▒▒░░▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓▓▓▓▒░░▒▓█\r\n"
					+ "██▓▒░░░░░░░░░░░░░░░░░░░░▒▒▒▒▒░░░▒▓▓▒▒▒▒▒▒▓▓▓▓▓█████▓▓▓▓▒▒▓▓█\r\n"
					+ "██▓▒░░░░░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░▒▓▓▓▒▒▒▒▒▒▓▓▓▓▓▓▓▓▓▓█▓▓▓▓▓▓██\r\n"
					+ "██▓▒░░░░░░░▒▒▒▓▓▒▓▒▒▒░░▒▒▓▓▒░▒▓▓▓▓▓▒▒▒▒▒▓▓███▓▓▓▓▒▒▓▓▓▓▓▓███\r\n"
					+ "██▓▒░░░░░░▒▓▓▓▓▓▓▒▒▓▒▒▒░▓▓▓▓▒▒░▒▒▒▒▒▒▒▒▓██████▓▓▓▓▓▒▓▓▓▓▓███\r\n"
					+ "██▓▒░░░░▒▒▓▓▓██▓▒▒▓▓▓▓▓▓▓▓▓░░░▒▒▒▓▒▒▒▒▓██████▓██▓▓▓▓▒▒▓▓▓▓██\r\n"
					+ "██▓▒░░▒▒▓▓████▓▒▓▓▓▒▓▓▓▓▓▓░▒▒▒▒▒▒▒▒▒▒▓████▒░░░░░▒▓▓▓▒▒▓▓▓███\r\n"
					+ "██▓▒░▒▓▓▓████▓▓▒▓▓▓▒▒▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▓██▓▓░▒▓▓░░▒░░▓▓▓▒▒▓████\r\n"
					+ "██▓▒▓▓▓▓█████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒░▒▒███▓░▓████▓██▓▒▓▓▒▒▒████\r\n"
					+ "██▓▓▓▓▓██▓▓██▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒░░▒▓███▒▓▓██████████▓▒▒▒▓███\r\n"
					+ "███▓▓▓██████▓░▒▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒░░▒▓███▒▓▓███████▓██▓▓▒▒▓███\r\n"
					+ "███▓▓███████▒░░▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒░▒▒▓█▓█▒█▒▒▓████████▓▓▓▒▒▓██\r\n"
					+ "████████████▒▒▓█▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒░▒▓█▓▓█▓▓▓▒▒▓██▓▓██▓▓▓▒▒▓▓██\r\n"
					+ "██████▓█████▒▓██▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▓▓▓▓▒▒▓█████▓▓▓▓▓▒▒▒▒▒▓▓██\r\n"
					+ "███▓▓███████▓▒▓█▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▓▓▓▓▓▒▒▒▒▒▒▒▓▓███\r\n"
					+ "█████████████▒▒▓█▓▓▓▓▓▓███▓▓▒▒░░░░░░▒▒▒▓▓▓▓███▓▓▓▓▓▓▓▓▓▓████\r\n"
					+ "█████████████▓▓█▓▓▓██▓▓▒░░░▒▒▓▓▓█████████▓░▒▒█████████▓▓████\r\n"
					+ "█████▓██████▓▓▓▒▓██▓▒▓▓███████████████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓████\r\n"
					+ "█████▓████▓▒▓▒▒▒▓▓▒▓███████▓▓▓▓▒▒▒▒▒▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓█████\r\n"
					+ "████▓████▓▒░▓▓▓▓▓▓▓█████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓████▓▓▓▓▓▓▓▓████████\r\n"
					+ "██████▓▓▓▒░░▓▓▓█████████████████████████████████████████████\r\n"
					+ "█████▓▓▓▒░░░▓▓▓▓▓███████████████████████████████████████████\r\n"
					+ "█████▓▓▒░░░▒▓▓█████████████████████████████████████████▓▓███\r\n"
					+ "█████▓▓░░░░▓▓████████████████████████████████████████▓▓▓▓███\r\n"
					+ "█████▓░░░░▒▓███████████▓▓▒▒▒▒▒▓▓███████████████████▓▓▓▓▓▓▓██\r\n"
					+ "████▓░░░░░▓▓███▓▓██████▓▓▓▓▓▓▓▓▓▓███████████████▓▓▓▓▓▓▓▓▒▓▓█\r\n"
					+ "██████▓▒░▒▓▓██▓██████▓▓▓▓▓▓▓▓▓███▓▓██████████▓▓▓▓▓▓▓▓▓▒░░▒▓█\r\n"
					+ "███████████▓▓▓▓█▓▓██████▓▓▓▒▒▒▓▓▓█▓▒▓██▓▓████▓▒▓▓▓▒▓▒░░░░▒██\r\n"
					+ "████████████████████████▓▓▓▓▓▓█▓██▓▓▓█████▓▓▓██▓▓▓▓▓▒▒▒▒▓▓██\r\n"
					+ "████████████████████████████████████████████████████████████/r/n");
			
			System.out.println ("\nFizz, a slippery Bilgewater Assassin, strikes from the shadows with deadly precision, using Mana to fuel his lethal abilities.\nAs an Assassin, he excels in high burst damage and mobility, quickly eliminating key targets before they can react. \nWith a reliance on Mana, Fizz must carefully manage his resources to maintain his offensive edge while darting in and out of combat to remain unpredictable and dangerous.\n\n");
			
		}
		
		else if (summoner.getName ().equals("Galio")){ //show Galio icon
			
			System.out.print("\r\n"
					+ "████████████████████████████████████████████████████████████\r\n"
					+ "███▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓█▓▓█████▓▓▓▓▓▓▓▓▓▓▓▓▓▓████\r\n"
					+ "███▓▓▓▓▓▓▓▓▓▓▓▓▒░▒███▓▓▓▓▓▓▓▓▓▓▓▓▓▓█▓███▓█▓█▓▓▓▓▓▓▓▓▓▒▓▓████\r\n"
					+ "███▓▓▓▓▓▓▓▓▓▓▓▓▒░▓██▓▓▓▓▓▒▒▒░░▒▓▓▓▓▓▒█████▓█▓▓▓▓▓▓▓▓▓▒▓▓▓███\r\n"
					+ "███▓▓▓▓▓▓▓▓▓▓▓▒▒░████▓▒░░░░░▒▒▓▓▓▓▓█▒▓████████▓▓▓▓▓▓▒▒▓▓▓███\r\n"
					+ "███▓▓▓▓▓▓▓▓▓▓▒▒░▒████▒░▒▒▒▒▒▒▒▓▓▓▓▓█▓▓███▓████▓▓▓▓▓▒░▒▓▓████\r\n"
					+ "███▓▓▓▓▓▓▓▓▓▓▒▒░▓█▓██▓▒▒▒▒░░░▒▓▓▓▓▓█▓▓██▓████▓▓▓▓▓▓░▒▓▓▓▓███\r\n"
					+ "███▓▓▓▓▓▓▓▓▓▒░░░▓█▓▓▓▓▒▒░░░▒▓▓██▓▓▒█▓███▓████▓▒▓▓█▓░█▓▓▓▓███\r\n"
					+ "███▓▓▓▓▓▓▓▒▒▒░░░▓▓▓▓▓▓▓▒▒▒▓▓▓█▓█▒▓▒█▒████████▓▒▓██▓▓█▓▓▓▓███\r\n"
					+ "███▓▓▓▓▓▓▓▒▒░░░░▓▒▓▓▓▒░░▒▓▓▓▓███▒▒▓█▒████████▓▓▓████▓▓▓▓▓███\r\n"
					+ "███▓▓▓▓▓▓▓▓▓▒░░░▓▓▒▓▓▓▒▒▓▓▓▓▓███▒░▓▓██████████▓▓███▓▓▓▓▓▓███\r\n"
					+ "███▓▓▓▓▓▓▓▓▓▓▓░░█▓▓▓▓▓▓▓████▓▓█▓▓░█▒██████████▓▓▓▓█▓▓▓▓▓▓███\r\n"
					+ "███▓▓▓▓▓▓▓▓▓▓▓▓▒▓▓▓▓▓▓▓▒▒█████▓▒▒▒▓▓███████████████▓▓▓▓▓▓███\r\n"
					+ "███▓▓▓▓▓▓▓▓▓▒▓▓▒▓▓▓▓▓▒▒▒▒▒▒▒▓▓▓▒░▓▒███████████████▓▓▓▓▓▓▓███\r\n"
					+ "███▓▓▓▓▓▓▒▒▒▒▒▓▓▓▓▓▓▓▒▒▒▒▒▒▒▒▒▒▒▒▓▓████████████▓██▓▓▓▓▓▓▓███\r\n"
					+ "███▓▓▓▓▒░░░▒▒▒▓▓▒▓▓▓▓▒░░░▒▒▒▒▒▒▒▒▓██████▓▓▓▓▓████▓▓▓▓▓▓▓▓███\r\n"
					+ "███▓▓▒░░░░▒▒▒▒▒▓▓▓▓▓▓▒░░░▒▒▒▒▒▒▒▓▓█████▓▒▒▒▒▓███▓▓▓▓▓▓▓▓▓███\r\n"
					+ "███▓░░░░░░░░░░▓▓█▒▓▓▒▒▒░░▒▒▒▒▒▒▒▓▓████▓▓▒▓▓▓███▓▓▓▓▓▓▓▓▓▓███\r\n"
					+ "███▒░░░░░░░░░░▒▓█▓▓▓▒░░▓▒░▒▒▒▒▒▓▓▓▓▓▓▓▓▒▓▓████▓▓▓▓▓▓▓▓▓▓▓███\r\n"
					+ "██▓▒░░░░░░░░░░▒▓▓▓▒▒▒░░░░░▒▒▒▒▒▒▓▓▓▓▒▒▒▓▓████▓▓▓▓▓▓▓▓▓▓▓▓███\r\n"
					+ "██▓▒░░░░░░▒▒▒▒░▓▓█░▒▒░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓█▓▓▓▓▓▓▓▓▓▓▓▓▓███\r\n"
					+ "██▓▒░░░░░░░▒▒▒▒▒▓▓░░░░░░░▒▒▒▒▒▒▒▒▒▒▒▓▓▓▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓███\r\n"
					+ "██▓▒░░░░░▒▒▒▒▒▓▒▒▓░░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒█▓▓▓▓▓▓▓▓▓▓▓▓▓▓███\r\n"
					+ "██▓▒░░░░░▒▒▒▓▒▒▒░▓▒░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓███\r\n"
					+ "██▓▒░░░░░░▒▒▒▓▒▓▓▒▓▒░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓███\r\n"
					+ "██▓▒░░░░░░▒▒▒▒▓▓▓▓▓█▒░░░░░▒▒▒▒▒▒▒▒▒▒▒▓██▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓███\r\n"
					+ "██▓▒░░░░░░▒▒▒▒▒▓▓▓▓▓▓▓▒░░▒▒▒▒▒▒▒▒▒▒▒▒▓██▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓███\r\n"
					+ "██▓▒▒░░▒▒░▒▒▒▒▒▒▓▓██▓██▒▒▒▒▒▒▒▒▒▒▒▒▒▓███▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓███\r\n"
					+ "███▓▒░▒▒▒▒▒▒▒▒▒▒▒▓▓██▓▓█▓▒▒▒▒▒▒▒▒▒▒▓████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓███\r\n"
					+ "███▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓████▓████▓▓▓▓▓▓▓▓▓████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓███\r\n"
					+ "█████▓██████████████████████████████████████████████████████\r\n"
					+ "████████████████████████████████████████████████████████████\r\n");
			
			System.out.println ("\nGalio, a towering Demacian Juggernaut, is a relentless force on the battlefield, drawing upon his Resourceless nature to unleash devastating attacks without concern for resource management. \nAs a Juggernaut, he excels at absorbing damage and overpowering enemies with his immense strength, dominating both the frontline and his foes. \nWith no need for mana or energy, Galio can continuously engage in battle, allowing him to be an unstoppable presence in every fight.\n\n");
			
		}
		
		else { //no icon for minions
			
		}
		
		System.out.println (summoner.getName () + " Stats:");
		
		//display identity of champion
		System.out.println ("\t" + summoner.getOwnership ());
		System.out.println ("\t" + summoner.getDistrict ());
		System.out.println ("\t" + summoner.getLegacy ());
		System.out.println ("\t" + summoner.getType ());

		//display physical characteristics of champion
		System.out.println ("\t(🖤). Health Points: " + summoner.getHealth());
		System.out.println ("\t(💞). Health Regeneration: " + summoner.getHealthRegen());
		System.out.println ("\t(🛡️). Shield: " + summoner.getShield());
		System.out.println ("\t(🎽). Armor: " + summoner.getArmor());
		System.out.println ("\t(👘). Magic Resist: " + summoner.getMagicResist());
		System.out.println ("\t(⚔️). Attack Damage: " + skills [summoner.getId ()][0].getAttackDamage());
		System.out.println ("\t(🎯). Crit Chance: " + summoner.getCritChance() + " %");
		System.out.println ("\t(💦). Life Steal: " + skills [summoner.getId ()][0].getLifeSteal() + " %");
		System.out.println ("\t(🪄). Ability Power: " + skills [summoner.getId ()][0].getAbilityPower());
		System.out.println ("\t" + summoner.displayResource() + "\n");
		System.out.println ("\t(🪣): Resource Regeneration: " + summoner.getResourceRegen () + "\n");
		
	}
	
	//display user champion & opponent visually
	public static void showRift (Champion blue, Champion red) {
		
		//user champion is Aempyrea vs opponent
		if (blue.getName().equals("Aempyrea")) {
			if (red.getName().equals("Aurelion")) { //opponent is Aurelion 
				System.out.println ("\r\n"
						+ "                                                                        ▒▓▓ █▓ ▓▓▒▒                 \r\n"
						+ "        ▓▓▓▓▓ ███                                                     ▒▒▓█████▓▓▓▓█                 \r\n"
						+ "     ▓▓██▓▓▓▓▓▓▒▓▓▓                                                   ▓▓▓███▓▓▓▓███                 \r\n"
						+ "    ▓▓██████▓▓█▒▓████                                                 ▓█▓▒█▓▓▓▓█████                \r\n"
						+ "   ▓▓█████▓▓█████▓▓█▓▓                                                  ▒▓▓▒▒▒▓▓▓███                \r\n"
						+ "    █████████████████▓▓                                                  ▒▒▒▒▓▒▓████                \r\n"
						+ "   ███████████████████                                                    ▒▓██▓███████ ▓▓▓█   ░░░░░ \r\n"
						+ "   ▓▓▓███ ████████████                                                   ▓████▓████▓███▒▓▒█ ░░░░░   \r\n"
						+ "   ▓▓████ ██████████▓                                                    █▓██▓██████████████░░░░░░  \r\n"
						+ "   █████  █████████████                                        ▓▒░▒      █▓██▓██████████████░░░░░░  \r\n"
						+ "    ████▓ ▓▓███████████                                        █▓░▒█    ██▓███▓████████▓▓███ ░░░░   \r\n"
						+ "    ███▓▓▓██████████▓██                                         █████▓▓██████████████████████  ░░   \r\n"
						+ "    ███▓▓███████▓███▓██                                           ██▓▓▓█████████████  █▓█████  ░░░  \r\n"
						+ "     ▓█▓▓█████████████                                              ██▓▓█▓███████████   ▓██▓    ░░  \r\n"
						+ "     ██▓▓████████████                                                 ▒▓███ █▓▓▓▓▓▓██▒▒         ░░░ \r\n"
						+ "      █▓▓▓█████  ████                                                 ░░▒   █▓▓▓▓░░▒▒▓▓▓       ░░░░ \r\n"
						+ "      █▓▓▓██     █████                                                  ▒░░ ▓▓▓▓▓▒▒▓▓▓▓▓▓▒   ░░░░░░ \r\n"
						+ "      ▓▓▓▓▓█      ████                                                      ▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒░░░░░░  \r\n"
						+ "     ███▓▓▓▓      ██████                                                    ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░    \r\n"
						+ "    ████▓▓▓▓      ███████                                                   ▒▒▒▒▒  ▒▒▒▒▒▒▒▒         \r\n"
						+ "   ██████▓▓▒                                                                 ▒░░░░  ▒▒▒▒▒           \r\n"
						+ "   ██████▓▓▒▓                                                                  ░░    ░░░            \r\n"
						+ "       ██▓▓▒▓                                                                ░░░░    ░░░            \r\n"
						+ "       ▓▓▒▒▒▒                                                                ░░░     ░░░            \r\n"
						+ "        ▒▒▒▒▒                                                                        ░░░░           \r\n"
						+ "         ▒▒▒▒                                                                         ░░            \r\n"
						+ "                                                                                                    \r\n"
						+ "                                                                                                    \r\n"
						+ "       [Aempyrea]                                                          [Aurelion]               \r\n");
			}
			
			else if (red.getName().equals("Fizz")) { //opponent is Fizz
				
				System.out.println ("\r\n"
						+ "                                                                                 ▓                  \r\n"
						+ "           ▓▓▓▓ ████                                                           ▓▓▓▓                 \r\n"
						+ "       ▓▓███▓▓▓██▓▓█                                                         ▓▓▓█▓▓ ▓               \r\n"
						+ "     ▓▓▓▓████▓▓▓▓▓▒▓██▓                                                       ▓███▓                 \r\n"
						+ "     ▓███████▓█▓█▓█████▓▓                                                     ▓▓█▓▓                 \r\n"
						+ "    █▓▓▓▓▓▓███▓████████▓▓                                                      ▓█▓                  \r\n"
						+ "     ████████████▓█████▓█                                                      ▓▓▓                  \r\n"
						+ "    █████████████████████                                                      ▓▓                   \r\n"
						+ "    ▓▓▓▓██  ████████████                                                       █▓                   \r\n"
						+ "    █▓████  ███████████▓                                                      ▓█▒▒▒▒▒▒▒▒▒▓▓▓▒▒▒     \r\n"
						+ "    ██████  █████████████                                                     ███▓▒▒▒▒▒▒▓▓▓▓██▓     \r\n"
						+ "     █████  ▓▓███████████                                                     ███▓▒▒▒▒▒▒▓▓▓▓▓█▓▓    \r\n"
						+ "     ██▓█▓▓▓██████████▓███                                                    ███▓█▓▒▒▓▓█▒▓██▓▓█▓▓  \r\n"
						+ "     ███▓▓████████▓███▓███                                                    ██▓▓▓▓▓▓▓▓▓▒▓▓█▓▓  ▓  \r\n"
						+ "     ███▓▓██████████████▓                                                     █▓▓██▓▓▓▓▓▓▓██▓▓      \r\n"
						+ "      ██▓▓▓█████████████                                                     █████▓██▓▓▓▓▓▓▓▓▓      \r\n"
						+ "      ▓█▓▓▓█████████████                                                    ████▓█▓ ▓▓▓▓▓█ ▓▓▓▓     \r\n"
						+ "       █▓▓▓███     █████                                                     ▓▓ ▓█  █▓▒▒▒█ ▓▓▓▓     \r\n"
						+ "       ▓▓▓▓▓██     ██████                                                   ▓▓█▓    ▓▓▒▒▓▓▓█▓▓      \r\n"
						+ "       ██▓▓▓▓       █████                                                ▓▓▓▓▓▓▓  ▓▓▓▓▓▓▓▓▓▓█▓      \r\n"
						+ "      ███▓▓▓▓       ████████                                            ▓▓▓▓ ▓▓▓▒ ▓██▓▓▓▓███        \r\n"
						+ "     █████▓▓▒▓      ████████                                            ▓█▓  ▓▓▓▓ ████   ████       \r\n"
						+ "    ██████▓▓▒▓▒                                                        ▒▓█▓  ▓██▓▓██  ▓    █████▓   \r\n"
						+ "     ███▓█▓▓▒▓▓                                                        ▒▓▓▒  ▒▓█▓▒                  \r\n"
						+ "        ▓█▓▓▒▓▓                                                         ▒▒   ▒▒▒▒                   \r\n"
						+ "         █▓▓▒▒▒                                                               ░                     \r\n"
						+ "         ▒▒▒▒▒▒                                                                                     \r\n"
						+ "          ▒▒▒▒▒                                                                                     \r\n"
						+ "            ▒▒                                                                                      \r\n"
						+ "                                                                                                    \r\n"
						+ "        [Aempyrea]                                                                [Fizz]            \r\n");
			}
			
			else { //opponent is Galio
				
				System.out.println ("\r\n"
						+ "                                                                               ░▒         ░▒        \r\n"
						+ "                                                                               ░░▒        ░▒▒       \r\n"
						+ "                                                                               ▒░░       ░▒▓▒░      \r\n"
						+ "                                                                               ▒▒░       ░▒▓▒▒      \r\n"
						+ "                                                                               ▒▓▒  ░    ▓▓▓▓▒▒     \r\n"
						+ "            ▓▓▓▓ ▓███                                                         ░▒▓▒▓▒▒▒▓   ▓▓▓▓▓▒    \r\n"
						+ "        ▓▓███▓▓▓▒█▓▒▓▓                                                        ▒▓▓░▓▓▓▓▒   ▓▓▓▓▓▓▒   \r\n"
						+ "       ▓▓▓██▓██▓▓▓▓▓▓███▓                                                     ▓▓▓ ▓▒▒▓▒  ░░▓▓▓▓▓▒▒  \r\n"
						+ "      ▓▓█████▓▓▓██▓██▓▓█▓▓                                                  ▒▒▓▓▓▒▒▓▒▒▒▒▒▒▒░▓██▓▓▓  \r\n"
						+ "     ▓█▓▓▓▓▓███▓████████▓▓▓                                               ▒▒▒▓▓▒░░▒▒▒▒░░▒▒▒░▒▒▓▓▓▓▒ \r\n"
						+ "      ████████████▓███████                                                ▒▒▒▓▒▒▒▒▒▒▒▒░▒▒░▒▒▒▓▓▓██▓ \r\n"
						+ "     ▓████████████████████                                                ▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▒▓▓▒▒▒▓█▓▓ \r\n"
						+ "     ▓▓▓▓██▓ █████████████                                                ▒▓▓▓▓▓▓▒▒▒▒▓▓▓▓▓▓▓▓▓▒▒▓▓▓ \r\n"
						+ "     ▓▓████▓ ███████████▓                                                 ▓▓▓▓█▓▓▒▒▒▒▓▓▓▓▓█▓▓▒▒▒▓▓  \r\n"
						+ "     █████▓  ███████▓█████▓                                             ▒▓▒▓▓▓█▓▓▓▓▓▓▓▓▓▓   ▓▓▓▓▓▓░ \r\n"
						+ "      ██▓██▒ ▓▓████████████                                             ▓▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓    ▓▓▓▓▒▒░\r\n"
						+ "       █▓█▓▓▓▓█████████▓▓██                                             ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓█▓  ▒▓▓▒▒▒▒▒\r\n"
						+ "      ▓█▓▓▓▓███████▓████▓██                                             ▓▓▓▓▓▓▓▓█▓▓▓▓▓██▓▓▓  ▓▓▒▒▒▒ \r\n"
						+ "       ██▓▓▓██████████████                                             ▒▒▒▓▓ ▓▓▓▓█▓▓▓██▓▓▓▓   ▓▓▒▒▓ \r\n"
						+ "       ▓█▓▓▓██████████████                                             ▒▓▓▓  ▓▓▓▓▓  ▓█▓▓▓▓▓   ▓▓▓▒▓▒\r\n"
						+ "        █▓▓▓█████████████                                              ▒▓▓▒  ▓▓▓▓▓  ▓▓█▓▓▓   ▓▓▓▓▓▓ \r\n"
						+ "        ▓█▓▓▓██ █   ██████                                                   ▓▓██▓▓▓▓▓▓▓▓▒   ▓▒▓▓▒  \r\n"
						+ "        ▓█▓▓▓██     ██████                                                   ▓▓▓▓▓    ▓▓▓▓     ▒▒   \r\n"
						+ "        ▓▓▓▓▓▓█      ██████                                                  ▓▓▓▓      ▓▓▓          \r\n"
						+ "       ███▓▓▓▓▒      ████████                                               ▒▓▓▓        ▓▓▓▓        \r\n"
						+ "       ████▓▓▓▓      █████████                                              ▓▓▓         ▓▓▓▓▓       \r\n"
						+ "     ██████▓▓▒▒▒                                                          ▒▓▓▓▓                     \r\n"
						+ "      █████▓▓▓▒▒                                                          ▓▓▓▓▓                     \r\n"
						+ "         ▓█▓▓▒▒▒                                                                                    \r\n"
						+ "          ▓▓▒▒▒▒                                                                                    \r\n"
						+ "           ▒▒▒▒▒                                                                                    \r\n"
						+ "           ▒▒▒▒▒                                                                                    \r\n"
						+ "             ▒▒                                                                                     \r\n"
						+ "                                                                                                    \r\n"
						+ "          [Aempyrea]                                                            [Galio]             \r\n");
			}
		}
		
		//user champion is Wizzy-Bars vs opponent
		else if (blue.getName().equals("Wizzy-Bars")) { 
			if (red.getName().equals("Aurelion")) { //opponent is Aurelion 
				System.out.println ("\r\n"
						+ "                                                                             ▓ ▒▒▒                  \r\n"
						+ "      ░▒                                                              ▒▒▓██████▓▓▓                  \r\n"
						+ "     ░▒▒                                                              ▓▓███▓▓▓▓██▓                  \r\n"
						+ "     ░▒▒                                                              █▓▓▓▓▓▓▓████▓                 \r\n"
						+ "     ░▒▒                                                                ▓▓▒▒▒▓▒▓███                 \r\n"
						+ "     ▒▒▒                                                                 ▒▒▒▓▒▓███▓                 \r\n"
						+ "     ▒▓▓                                                                 ▒▒██████████ █▓█▒  ░░░░░   \r\n"
						+ "     ▒▓▓                                                                 ▓▓███████▓███░▓▓▓ ░░░░░    \r\n"
						+ "     ▒▓▓                                                                ▓▓▓██▓████████████▓░░░░░    \r\n"
						+ "    ▓▓▓▓         ▒▒▒                                           ▓▒▒▒▒    █▓██▓█████████████▓░░░░░    \r\n"
						+ "     ▓▓▓      ▓▓▓▓▒▒▒▒▒                                        █▓░▒█▓  ▓██████████████▓▓██▓░░░░     \r\n"
						+ "     ▓█       ▓▓▓██▓▓▓▓                                         ▓███▓▓█▓██▓███████████▓███▓  ░░     \r\n"
						+ "     ██ ███       ▓██▓▓                                           ▓█▓▓▓▓███████████░ ▓▓███▓   ░░    \r\n"
						+ "     ▓███▓▓█▓▓▓███████                                               ▓▓▓▓▓███▓█████▓░░ ▓█▓    ░░░   \r\n"
						+ "     ████▓▓██████▓▓████                                              ░░░▓▓ ▓█▓▓▓▓▓▓▓▒▓        ░░░   \r\n"
						+ "    █▓██████▓████▓█▓▓▓▓                                               ░░░░░░▓▓▓▒░░▒▓▓▓▓▒    ░░░░░   \r\n"
						+ "   ▓█▓▓▓█████████████                                                      ░▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒░░░░░    \r\n"
						+ "   ██▓▓██▓▓███▓▓████                                                       ░▒▓▓▓▓▒▓▓▓▒▒▒▒▒░░░░░     \r\n"
						+ "    ███████▓█▓█████████                                                    ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒       \r\n"
						+ "     ██    █████████████                                                    ▒▒░░░ ░▒▒▒▒             \r\n"
						+ "     ██ ▓█████████████                                                        ░░░  ░░░░             \r\n"
						+ "    ███▓█████      ██                                                        ░░░    ░░░             \r\n"
						+ "    ████▓███       ███▓                                                     ░░░     ░░░             \r\n"
						+ "    ██▓██████   ███████████                                                         ░░░             \r\n"
						+ "       █████      ███████████                                                        ░░             \r\n"
						+ "                                                                                                    \r\n"
						+ "        [Wizzy-Bars]                                                      [Aurelion]                \r\n");
			}
			
			else if (red.getName().equals("Fizz")) { //opponent is Fizz
				
				System.out.print("                                                                                                    \r\n"
						+ "      ░░                                                                         ▓▓                 \r\n"
						+ "      ░▒                                                                        ▓▓▓▓                \r\n"
						+ "      ░▒▒                                                                     ▓▓▓█▓▓▓               \r\n"
						+ "     ░░▒▒                                                                      ▓███▓                \r\n"
						+ "     ▒▒▒▒                                                                      ▓▓█▓▓                \r\n"
						+ "     ▒▒▒▓                                                                       ██                  \r\n"
						+ "     ▒▓▓▓                                                                       ▓▓                  \r\n"
						+ "     ░▒▓▓                                                                       █▓                  \r\n"
						+ "     ▓▒▓▒                                                                      ▓█▓  ▒▒▒▒▒▒▒▒        \r\n"
						+ "     ▓▓▓▓      ▓▓▓▓▒▒▒▒▒                                                       ██▓▓▒▒▒▒▒▒▓▓▓▓▓▒     \r\n"
						+ "     ███      ▓▓▓██▓▒▒▒▒                                                       ███▒▒▒▒▒▒▒▒▓▓▓█▓▒    \r\n"
						+ "     ▓██▓██       ▓██▓▒                                                        ██▓▓▓▒▒▒▒▓▓▓▓█▓█▓▓   \r\n"
						+ "     ▓█▓█▓▓▓▓▓▓ ██████▓                                                        ███▓▓▓▓▓▓▓▓▓▓█▓▓▓█▓▓ \r\n"
						+ "      ████▓▓███████████                                                        ██▓▓▓▓▓▓▓▓▓▓▓█▓▓     \r\n"
						+ "      ███▓█████▒█████▓▓▓                                                      ███▓█▓▓▓▓▓▓▓▓▓█▓▓     \r\n"
						+ "   ▓██▓█████▒████████▓▓                                                       ████████▓▓▓██▓▓▓▓     \r\n"
						+ "    ██████▓▓▓███▓▓█▓                                                          ▓▓▓▓▓▓ █▓▒▒▓██▓▓▓     \r\n"
						+ "    ██████████████████                                                       ▓▓█     ▓▒▒▒▓▓ █▓▓     \r\n"
						+ "    ███▓█   █████████████                                                  ▓▓█▓▓▓   ▓▓▓▒▓▓▓▓██▓     \r\n"
						+ "     ██   █████████████                                                   ▒█▓▓▓▓▓▒ ▓▓▓▓▓▓▓█▓█       \r\n"
						+ "     ██▓██████     ██▓                                                   ▓▓▓  ▓▓▓▓ ███    ███       \r\n"
						+ "     ███▓▓▓██       ███▓                                                ▒▓▓▓  ▓▓█▓████▓ ▓▓████▓     \r\n"
						+ "    ██████████    ████████                                               ▓▓▒  ▒▓█▒                  \r\n"
						+ "     █████████   █████████████                                           ▒▒   ▒▓▒▒                  \r\n"
						+ "        ██                                                                     ▒                    \r\n"
						+ "                                                                                                    \r\n"
						+ "        [Wizzy-Bars]                                                                [Fizz]          \r\n");
				
			}
			
			else { //opponent is Galio
				
				System.out.println ("\r\n"
						+ "                                                                             ▒▒         ░▒          \r\n"
						+ "                                                                             ░▒        ░░▒▒         \r\n"
						+ "                                                                             ░░        ░▒▓▒░        \r\n"
						+ "                                                                            ░▒░        ░▒▓▒▒        \r\n"
						+ "                                                                            ▒▒▒       ▒▒▒▒▓▓▒       \r\n"
						+ "     ░░▒                                                                    ▒▓▓▒▒░▒▒▒  ▓▓▓▒▓▓▒      \r\n"
						+ "     ░▒▒                                                                   ▓▓▓▓▒▒▓▓▒▒   ▓▓▓▓▓▓▓     \r\n"
						+ "     ░▒▒                                                                   ▓▓▓▒▓▓▒▒▓▒    ▓▓▓▓▓▓▒    \r\n"
						+ "     ▒▒▒                                                                  ░▒▓▓ ░▓▓▓▒▒  ▒▒▒█▓▓▓▓▓▓   \r\n"
						+ "     ▒▒▓                                                                ▒▒▒▓▓▓▒▓▒▒▒▓▒▓▒▒▒░▒▓████▓   \r\n"
						+ "     ▒▓▓                                                               ▒▒▒▓▒░░░░░░░░░░▒▒▒░▒▓▒▒█▓▓▒  \r\n"
						+ "     ▒▓▓                                                               ▒▒▒▓▓▒▒▓▒▒▓▒▒▒▒▒░▒▒▓▓▓▓▓▓▓▒  \r\n"
						+ "     ▓▓▒                                                               ▒▒▒▓▓▓▒▓▓▓▓▓▒▓▓▓▓▒▓▓▒▒▓▓█▓▓  \r\n"
						+ "     ▓▓▓     ▓▓▓▓▓▒▒▒▒                                                 ▓▓▓▓▓▓▓▓▒▒▒▓▓▓▓▓▓▓▓▒▓▒▒▒▓▓   \r\n"
						+ "     ▓█▓     ▓▓▓▓▓▓▓▓▒                                                ▒▓▓▓▓█▓▓▓▒▒▒▒▓▓▓▓▓█▓▓▒▓▓▓█▓   \r\n"
						+ "     ██▓██▓     ▓▓██▓▒                                               ▒▒▒▓▓▓██▓▓▓▓▓▓▓▓▓▓   ▓▓▓▓▓▓▒░  \r\n"
						+ "     ▓██▓▓▓█▓▓▓██████                                                ▓▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓    ▓▓▓▓▒▒░  \r\n"
						+ "     ███▓▓████████████                                               ▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓   ▓▓▒▒▓▒▒  \r\n"
						+ "   ▓▓██████▓▓█████▓▓▓▓                                               ▓▓▓▓ ▓▓▓██▓▓▓▓███▓▓▓  ▓▓▒▒▓▒▒  \r\n"
						+ "   ▓█▓▓▓█▓██████████                                                ▓▒▓▓▓ ▓▓▓▓▓█▓▓▓██▓▓▓▓   ▓▓▒▓▒▓  \r\n"
						+ "   ▓█▓▓██▓███▓█████                                                 ▓▓▓▓▒ ▓▓▓▓▓▓  ▓▓▓▓▓▓▓   ▓▓▓▓▒▓  \r\n"
						+ "    ██▓██  ▓█████████▓▓                                             ▓▓▓▓  ▓▓▓▓▓   ▓▓▓▓▓▓    ▓▓▓▒▓▓  \r\n"
						+ "     ██  ▓███████████▓                                                    ▓▓███▓▓▓▓▓██▓▓   ▓▓▒▒▒▒   \r\n"
						+ "     ██▓██▓██▓   ██▓                                                      ▓███▓▓▓▓  ▓▓▓      ▓▓▒    \r\n"
						+ "    ▓██▓▓▓██      ██▒▒                                                    ▓▓▓▓▓      ▓▓▓            \r\n"
						+ "    ██▓██████   ████████▓                                                 ▓▓▓▓       ▓▓▓▓           \r\n"
						+ "    ▓███████▓   ███████████▓                                             ▒▓▓▓        ▓▓▓▓▓          \r\n"
						+ "       ▓▓                                                               ▒▓▓▓▒          ▓▓▓          \r\n"
						+ "                                                                       ▓▓▓▓▓▓                       \r\n"
						+ "                                                                       ▒▓▓▓                         \r\n"
						+ "       [Wizzy-Bars]                                                            [Galio]              \r\n");
				
			}
		}
		
		//user champion is Cake vs opponent
		else {
			
			if (red.getName().equals("Aurelion")) { //opponent is Aurelion 
				
				System.out.print("\r\n"
						+ "                                                                                                    \r\n"
						+ "                                                                    ▒▒▓ ▓███▓▓▒▓                    \r\n"
						+ "                                                                  ▒▒▓▓████▓▓▓▓█                     \r\n"
						+ "                                                                  ▓▓▓██▓▓▒█▓████                    \r\n"
						+ "                                                                  ▓█▒▓▓▓▓▒▓██████                   \r\n"
						+ "                                                                    ▓▓▓▒▓▒▒▓▓▓███                   \r\n"
						+ "                                                                     ▒▒▒▒▓▒▒▓████                   \r\n"
						+ "                                                                       ▓▓▓▓▓███████ ▓█▓█     ░░░░   \r\n"
						+ "   ▓▓▓▓▒                                                               ▓████████▓███▓▓▒██ ░░░░░     \r\n"
						+ "     ▓▓▓▒▒▒      ███                                                 ▓▓▓████████████▓▒███ ░░░░░░    \r\n"
						+ "      ▒▒▓▓▓▓▓▒░░▒█████                                      ▒░       ██▓██████████████████░░░░░░░   \r\n"
						+ "       ░  ▓▒▓█▓▓▒▒▓████                                   ██▒░▒█     ████████████████▓████░░░░░░    \r\n"
						+ "         ▒▒▓▓███▓▓██▒░░                                    ██▒▒██   ███▓█████████████▓████ ░░░      \r\n"
						+ "          ░▒▒▓█▒▓▓█▓▓▒▓▓▒                                    ███▓▓▓▓██████████████████████   ░░     \r\n"
						+ "              ▓█▓███▓▓██▓▓▓                                   ██▓▓▓▓▓████████████   ▓▓████    ░░    \r\n"
						+ "              ▓████▓████▓█▓██▓▓▓██                               █▓▓▓▒████████████▓░░ ███     ░░░   \r\n"
						+ "              ████████████▓▓▓█▓   ███                             ░░▓██ ██▓▓▓▓▓▓▓▓▒▒          ░░░   \r\n"
						+ "              █████▓██▓▓   ░▓░▒▒                                  ░░░░   █▓▓▓▒░░░▓▓▓▓▓       ░░░░   \r\n"
						+ "            ██████▓█▓▓      ▓ ▓▒                                    ░░░░░▓▓▓▓▓▒▒▓▓▓▓▓▓▒▒  ░░░░░░░   \r\n"
						+ "    ██      ████████████                                                 ▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒░░░░░░    \r\n"
						+ "     ███   █████████████▓███                                             ▒▒▒▓▓▒▒▒▒▒▒▒▒▒▒▒▒░░░░      \r\n"
						+ "     ████████  █████████████                                             ▒▒▒▒   ▒▒▒▒▒▒ ▒            \r\n"
						+ "      ██       █████   ████▓▓                                            ▒▒░░░   ▒▒▒▒▒              \r\n"
						+ "               ██████      █                                               ░░░    ░░░               \r\n"
						+ "               ███                                                         ░░░    ░░░               \r\n"
						+ "               ███                                                        ░░░     ░░░               \r\n"
						+ "               ████                                                       ░░       ░░░              \r\n"
						+ "                ███                                                                ░░░              \r\n"
						+ "                                                                                                    \r\n"
						+ "              [Cake]                                                      [Aurelion]                \r\n");
				
			}
			
			else if (red.getName().equals("Fizz")) { //opponent is Fizz
				
				System.out.println ("\r\n"
						+ "                                                                                  ▓                 \r\n"
						+ "                                                                                 ▓▓▓                \r\n"
						+ "                                                                               ▓▓▓█▓▓▓              \r\n"
						+ " ▒▓▒                                                                            ▓██▓                \r\n"
						+ "   ▓▒▓▓▓▒▒░                                                                     ▓██▓                \r\n"
						+ "     ▓▒▓▓▓  ▒▒▒ █████                                                           ▓█▓                 \r\n"
						+ "      ▒▒ ▒▓▓▓▓▒▒▓▓███                                                            █                  \r\n"
						+ "        ▒▓▓█▓█▓▓▓██████                                                         ██                  \r\n"
						+ "        ▒░▓▓▓▓▓▓███▓▒▒▓                                                        ▓▓▓▓▒▒▒▒▒▒▒▒▒▒▒      \r\n"
						+ "            ▒▓▓▓▓██▒▒▒▓▓                                                        ███▓▒▒▒▒▒▓▓▓██▒     \r\n"
						+ "              ▓██████▓▓▓▓█▓███                                                  ██▓▒▒▒▒▒▓▓▓▓▓█▓▒    \r\n"
						+ "             ▓▓█████▓████▓███▓▓▓██▓                                             ████▓▒▓▓█▓▓▓█▓▓█▓   \r\n"
						+ "            ▓█████████████▓▓▒▓▒                                                ██▓▓▓▓▓▓▓▓▒▓▓█▓▓     \r\n"
						+ "           █  █▓██▓█▓      ▒▒▒▓▒                                               ██▓▓█▓▓▓▓▓▓▓█▓▓      \r\n"
						+ "   █       ███████████                                                        ▓███████▓▓▓█▓▓▓▓      \r\n"
						+ "   ███     ███████████▓█                                                      █▓█▓▓▓  ▓▒▒▓ █▓▓▓     \r\n"
						+ "    █████████ ▓███████████ ██                                                 █▓█    ▓▓▒▒▓█ ▓▓      \r\n"
						+ "    ██████    █████████████▓                                                ▓▓█▓▓▓  ▓▓▓▒▓▓▓▓█▓      \r\n"
						+ "               █████   █████                                               ▓█▓▓▓▓▓▒▓▓▓▓▓▓▓███       \r\n"
						+ "              ███                                                         ▓▓▓  ▓▓▓▓████   ███       \r\n"
						+ "              ███                                                        ▒▓█▓  ▓▓▓▓██ ▓▓ █ ██████   \r\n"
						+ "              ████                                                        ▒▓▒  ▓▓▓▒                 \r\n"
						+ "              ████                                                         ▒▒   ▒▒                  \r\n"
						+ "                                                                                                    \r\n"
						+ "             [Cake]                                                                 [Fizz]          \r\n");
				
			}
			
			else { //opponent is Galio
				
				System.out.println ("\r\n"
						+ "                                                                              ▒▒         ░▒▒        \r\n"
						+ "                                                                              ░▒         ░▒▒        \r\n"
						+ "                                                                             ▒░░         ░▓▒▒       \r\n"
						+ "                                                                             ▒▒░        ░▒▓▓▒       \r\n"
						+ "                                                                             ▒░░        ░▒▓▒▓▒      \r\n"
						+ "                                                                             ▒▓▓ ░░░▒   ▓▓▓▓▓▓▒     \r\n"
						+ "                                                                            ░▓▓▓▒▓▒▒▓▓   ▓▓▓▓▓▓▒    \r\n"
						+ "                                                                            ▒▓▓▓▒▓▓▓▓▒   ▓▓▓▓▓▓▓▒   \r\n"
						+ "                                                                            ▓▓█ ▓▓▒▒▓▒    ▓▓█▓▓▓▓▒  \r\n"
						+ " ░▒▓▒                                                                     ▒▒▒▓▓ ░▓▓▓▒▒▒ ░▒▒▓█▓▓▓▓▓  \r\n"
						+ "   ▒▓▓▓▓▒▒░                                                              ▒▒▒▓▓▒▒▒▒░▒▓▒▒▒▒▒▒░▒▓▓▓▓▓▒ \r\n"
						+ "     ▓▒▓▓▓▒▒▒▒▒░█▓███                                                  ▒▒▒▒▓▒░░░░░░░░░░▒▒▒▒▒▒▒▒▓▓▓▓ \r\n"
						+ "      ▒▒ ▓▓▒▓▓▒▒▓▓████                                                  ▒░▒▓▓▒▒▒▒▒▒▒▒▒▒▒░▒▒▒▓▓▓▓▓▓▓ \r\n"
						+ "         ▓▓▓▓█▓▓▓▓████▓                                                 ▒▒▓▓▓▒▓▓▓▓▓▓▒▒▓▓▓▓▓▓▒▒▒▓██▓ \r\n"
						+ "         ░▒▓▓▓▓▓▓██▓▒▒▓                                                ░▓▓▓▓▓▓▓▓▒▒▒▓▓▓▓▓▓▓▓▓▓▓▒▒▓▓▓ \r\n"
						+ "           ░▒▓▓▓▓██▓▒▒▓▓                                               ▒▓▓▓▓█▓▓▒▒▒▒▒▓▓▓▓▓██▓▒▓▒▓▓▓▓ \r\n"
						+ "              ▓██████▓▓▓▓█▓▓▓▓                                        ▒▒▒▓▓▓█▓▓▓▓▒▓█▓▓▓▓   ▓▓▓▓▓▓▓░ \r\n"
						+ "             ▓▓████▓▓████▓██▓▓▓▓▓▓▓▓▓                                ▒▓▒▓▓▓▓█▓▓▓▓▓▓▓▓▓▓▓     ▓▓▓▓▒▒░\r\n"
						+ "             ▓████████████▓▓▒▓▒                                      ░▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓   ▓▓▒▒▒▒▒▒\r\n"
						+ "           ▓▓ ████▓█▓  ▒   ▒▓▓▒▒                                     ▓▓▓▓▓▓▒▓▓█▓▓▓▓▓▓███▓▓  ▓▓▓▒▒▓▒▒\r\n"
						+ "   ▓       ██████████▓                                              ░▓▓▓▓▓░▓▓▓▓█▓▓▓▓███▓▓▓   ▓▓▓▒▓▒▒\r\n"
						+ "   ▓██     ███████████▓▓                                            ░▒▓▒▓▓ ▓▓▓▓▓▓▓▓██▓▓▓▓▓    ▓▓▓▒▓▒\r\n"
						+ "    ██████████▓██████████▓▓▓▓                                       ▒▓█▓▓  ▓▓▓▓▓   ▓█▓▓▓▓▓    ▓▓▓▓▓▓\r\n"
						+ "    ▓██████    ████████████▓                                         ▓▓▒   ▓▓▓▓▓  ▒▓▓█▓▓▓▒   ▓▓▓▓▓▒▓\r\n"
						+ "               ██████  █████▓                                              ▓▓███▓▓▓▓▓▓▓▓▓    ▒▒▓▓▒  \r\n"
						+ "              ▓███                                                         ▒▓▓▓▓     ▓▓▓▓      ▒▒░  \r\n"
						+ "              ▓██▓                                                         ▒▓▓▓▓      ▓▓▓           \r\n"
						+ "               ███                                                         ▓▓▓        ░▓▓▓          \r\n"
						+ "               ███                                                        ▓▓▓         ░▓▓▓▓▓        \r\n"
						+ "                ▓▓                                                       ▒▓▓▓           ▓▓▓▓        \r\n"
						+ "                                                                        ▓▓▓▓▓                       \r\n"
						+ "                                                                        ▓▓▓▓                        \r\n"
						+ "              [Cake]                                                           [Galio]              \r\n");
				
			}
		}
		
	}
	
	public static boolean arena (Champion blue, Champion red, Abilities [][] skills, Item [][] shop, int gold) {
		
		//end battle when player HP is <= 0
		if (blue.getHealth () <= 0) { 
			return false;
		}
		
		//end battle when opponent HP is <= 0
		else if (red.getHealth () <= 0) {
			return true;
		}
		
		//display champion
		showRift (blue, red);
		
		//display basic stats between player & opponent
		System.out.println("Opponent: " + red.getName() + "\tHp: " + red.getHealth() + " HP\t\tShield: " + red.getShield () + "\tResource: " + red.getResourceSupply () + " " + red.getResourceType ());
		System.out.println("\nPlayer: " + blue.getName() + "\tHp: " + blue.getHealth() + " HP\t\tShield: " + blue.getShield () + "\tResource: " + blue.getResourceSupply () + " " + blue.getResourceType () + "\t Gold: " + gold + "\t Level: " + blue.getLevel () + "\t Total Experience: " + blue.getExperience ());
		
		//show choices of play
		System.out.println ("\nMake a move!\tTo Inspect Game Manual & Rule Books: ['i']\n\nAttack: ['a']\t\tFarm: ['f']\t\tBlock ['b']\t\tShop: ['p']\t\tView Stats: ['s']\t\tView Opponent Stats: ['o']");
		Scanner scanner = new Scanner (System.in);
		
		String play = scanner.nextLine ();
		
		//ensure valid player move
		while (!play.equals("i") && !play.equals("a") && !play.equals("f") && !play.equals("b") && !play.equals("p") && !play.equals("s") && !play.equals("o")) {
			System.out.println("Invalid Input!");
			System.out.println ("\nMake a move!\tInspect Game Manual & Rule Books: ['i']\n\nAttack: ['a']\t\tFarm: ['f']\t\tBlock ['b']\t\tShop: ['p']\t\tView Stats: ['s']\t\tView Opponent Stats: ['o']");
			play = scanner.nextLine ();
		}
		
		//fill champion to replace minion during non-farming move
		Champion dummy = new Champion ();
		
		if (play.equals("a")) { //attack opponent
			return battle (blue, red, dummy, skills, shop, gold, play);
		}
		
		else if (play.equals ("f")) { //farm minions
			Champion minion = spawnMinion (blue, skills); //randomly generate a minion
			return battle (blue, red, minion, skills, shop, gold, play);
		}
		
		else if (play.equals("b")) { //block opponent
			return battle (blue, red, dummy, skills, shop, gold, play);
		}
		
		else if (play.equals("p")) { //show shop
			showShop (blue, red, skills, shop, gold);
		}
		
		else if (play.equals("s")) { //show player's stats
			showChampion (blue, skills); 
			arena (blue, red, skills, shop, gold);
			
		}
		
		else if (play.equals("o")) {//show opponent's stats
			showChampion (red, skills);
			arena (blue, red, skills, shop, gold);
			
		}
		
		else if (play.equals ("i")) { //show game rule book
		
			gameKnowledge ();
			arena (blue, red, skills, shop, gold);
		}
		
		else { //ensure user input is valid
			System.out.println ("Invalid Input");
			arena (blue, red, skills, shop, gold);

		}
		
		return true;
	}
	
	//generate minions randomly
	public static Champion spawnMinion (Champion summoner, Abilities [][] skills) {
		
		//create minions
		Champion range = new Champion ("Caster Minion", "Piltover", "Mage", "Resourceless", false, false, 6, 0, 0, 100, 0, 0, 10, 0, 0, 0, 0, 1.0);
		Champion creep = new Champion ("Melee Minion", "Piltover", "Juggernaut", "Resourceless", true, false, 7, 0, 0, 150, 0, 0, 20, 0, 0, 0, 0, 1.0);
		Champion cannon = new Champion ("Cannon Minion", "Piltover", "Juggernaut", "Resourceless", true, false, 8, 0, 0, 250, 0, 0, 10, 0, 0, 0, 0, 1.0);
		Champion turret = new Champion ("Turret Minion", "Fire", "Piltover", "Resourceless", false, false, 9, 0, 0, 500, 0, 0, 10, 0, 0, 0, 0, 1.0);
				
		//generate weaker minions during level 3 or less
		if (summoner.getExperience () <= 5) {
			int spawn = (int)(Math.random () * 2);
			if (spawn == 0) { //spawn melee minion
				System.out.println("A " + range.getName () + " appeared!");
				showChampion (range, skills);
				return (range);
			}
			else { //spawn caster minion
				System.out.println("A " + creep.getName () + " appeared!");
				showChampion (creep, skills);
				return (creep);
			}
		}
		
		//generate stronger minions during level 4 or more
		else {
			int spawn = (int)(Math.random () * 2) + 2;
			if (spawn == 2) { //spawn cannon minion
				System.out.println("A " + cannon.getName () + " appeared!");
				showChampion (cannon, skills);
				return (cannon);
			}
			else { //spawn turret minion
				System.out.println("A " + turret.getName () + " appeared!");
				showChampion (turret, skills);
				return (turret);
			}
		}
	}
		
	//determine play route
	public static boolean battle (Champion blue, Champion red, Champion minion, Abilities [][] skills, Item [][] shop, int gold, String play) {
		
		if (play.equals("a")) { //attack move
			 return attackMove (blue, red, minion, skills, shop, gold, "a");
			 
		}
		
		else if (play.equals("f")) { //farm move
			return attackMove (blue, red, minion, skills, shop, gold, "f");
			
		}
		
		else { //block move
			blue.defend (blue, skills [blue.getId()][5]); //add shield & resource supply
			
			//describe block move
			System.out.println(blue.getName () + " Defended! " + blue.getName () + " gained: " + skills [blue.getId()][5].getShield () + " Shield & " + blue.getResourceSupply () + " " + blue.getResourceType () + "\n");
			
			return opponentTurn (blue, red, minion, skills, shop, gold); //switch over to opponent turn
		}
	}
	
	//determine abilities usage
	public static boolean attackMove (Champion blue, Champion red, Champion minion, Abilities [][] skills, Item [][] shop, int gold, String play) {
		
		 Scanner scanner = new Scanner (System.in);
		 
		 //display basic stats between player & minion
		 if (play.equals ("f")) {
			 System.out.println("\nMinion: " + minion.getName() + "\tHp: " + minion.getHealth ());
				
			System.out.println("\nPlayer: " + blue.getName() + "\tHp: " + blue.getHealth () + "\t\tShield: " + blue.getShield ()+ "\tResource: " + blue.getResourceSupply () + "\t Gold: " + gold + "\t Level: " + blue.getLevel () + "\t Total Experience: " + blue.getExperience () + "\n");
		 }
		 
		 System.out.println("\nTo Inspect Ability: ['i']\n");
		 
		//display cooldown & availability of abilities excluding block
		 for (int i = 0; i < skills [blue.getId ()].length - 1; i ++) {
				
				if (skills [blue.getId ()][i].getCooldown (skills [blue.getId ()][i].getId ()) != 0) {
					System.out.print ("['" + skills [blue.getId ()][i].getTrait () + "']. " + skills [blue.getId ()][i].getName () + ": On Cooldown (" + skills [blue.getId ()][i].getCooldown (skills [blue.getId ()][i].getId ()) + ") Turns\t");
				}
				
				else {
					System.out.print ("['" + skills [blue.getId ()][i].getTrait () + "']. " + skills [blue.getId ()][i].getName () + ": Available\t");
				}
		}
		 
		 System.out.println("\n");
		 String combo = scanner.nextLine ();
		 
		 while (!combo.equals("i") && !combo.equals("a") && !combo.equals("q") && !combo.equals("w") && !combo.equals("e") && !combo.equals("r")) {
			 System.out.println ("Invalid Input!");
			 
			 System.out.println("\nTo Inspect Ability: ['i']\n");
			 
			//display cooldown & availability of abilities excluding block
			for (int i = 0; i < skills [blue.getId ()].length - 1; i ++) {
						
				if (skills [blue.getId ()][i].getCooldown (skills [blue.getId ()][i].getId ()) != 0) {
					System.out.print ("['" + skills [blue.getId ()][i].getTrait () + "']. " + skills [blue.getId ()][i].getName () + ": On Cooldown (" + skills [blue.getId ()][i].getCooldown (skills [blue.getId ()][i].getId ()) + ") Turns\t");
				}
						
				else {
					System.out.print ("['" + skills [blue.getId ()][i].getTrait () + "']. " + skills [blue.getId ()][i].getName () + ": Available\t");
				}
			}	
			
			combo = scanner.nextLine ();
			
		 }
		 
		 //inspect ability stat
		if (combo.equals("i")) {
			System.out.print("Inspect Ability: ");
			combo = scanner.nextLine ();
			
			while (!combo.equals("a") && !combo.equals("q") && !combo.equals("w") && !combo.equals("e") && !combo.equals("r")) {
				System.out.println ("Invalid Ability!\tInspect Ability: ");
				combo = scanner.nextLine ();
			}
			 
			if (combo.equals("a")) {
				showAbilities (skills [blue.getId ()], 0);//show auto attack stats
			}
			 
			else if (combo.equals("q")) {
				showAbilities (skills [blue.getId ()], 1);//show 1st ability stats
			}
			 
			else if (combo.equals("w")) {
				showAbilities (skills [blue.getId ()], 2);//show 2nd ability stats
			}
			 
			else if (combo.equals("e")) {
				showAbilities (skills [blue.getId ()], 3); //show 3rd ability stats
			}
			 
			else {
				showAbilities (skills [blue.getId ()], 3); //show ultimate ability stats
			}
			 
			 attackMove (blue, red, minion, skills, shop, gold, play);
		 }
		 
		//use ability & ensure availability
		if (combo.equals("a")) { //use auto attack 
			return decide (blue, red, minion, 0, skills, shop, gold, play);
		}
		
		//use 1st ability while ensuring availability
		else if (combo.equals("q") && skills [blue.getId ()][1].getCooldown (skills [blue.getId ()][1].getId ()) == 0) { 
			return decide (blue, red, minion, 1, skills, shop, gold, play);
			
		}
		
		//use 2nd ability while ensuring availability
		else if (combo.equals("w") && skills [blue.getId ()][2].getCooldown (skills [blue.getId ()][2].getId ()) == 0) { 
			return decide (blue, red, minion, 2, skills, shop, gold, play);
			
		}
		
		//use 3rd ability while ensuring availability
		else if (combo.equals("e") && skills [blue.getId ()][3].getCooldown (skills [blue.getId ()][3].getId ()) == 0) { 
			return decide (blue, red, minion, 3, skills, shop, gold, play);
		}
		
		//use ultimate ability while ensuring availability
		else if (combo.equals("r") && skills [blue.getId ()][4].getCooldown (skills [blue.getId ()][4].getId ()) == 0) {
			return decide (blue, red, minion, 4, skills, shop, gold, play);
			
		}
		
		else { //ensure ability being used is available
			System.out.println ("Ability on Cooldown!");
			return attackMove (blue, red, minion, skills, shop, gold, play);
		}
	}
	
	//display ability stats
	public static void showAbilities (Abilities [] skills, int abilityId) {
		
		System.out.println(skills [abilityId].getName () + " Stats:");
		
		//show user inspected ability stat
		System.out.println ("\t(💰). Ability Cost: " + skills[abilityId].getAbilityCost ());
		System.out.println ("\t(💞). Heal: " + skills[abilityId].getHeal ());
		System.out.println ("\t(🛡️). Shield: " + skills[abilityId].getShield ());
		System.out.println ("\t(⚔️). Attack Damage: " + skills[abilityId].getAttackDamage ());
		System.out.println ("\t(🎯). Critical Bonus: " + skills[abilityId].getCrit ());
		System.out.println ("\t(💦). Life Steal Percentage: " + skills[abilityId].getLifeSteal () + " %");
		System.out.println ("\t(🪄). Ability Power: " + skills[abilityId].getAbilityPower ());
	
	}
	
	//decide attack route
	public static boolean decide (Champion blue, Champion red, Champion minion, int ability, Abilities [][] skills, Item [][] shop, int gold, String play) {
		
		//ensure sufficient resource supply for ability being used 
		if (blue.getResourceSupply () < skills[blue.getId()][ability].getAbilityCost ()) {
			System.out.println ("Insufficient Resource Supply!\tResource Supply: " + blue.getResourceSupply () + " " + blue.getResourceType () + "\tAbility Cost: " + skills[blue.getId()][ability].getAbilityCost () + " " + blue.getResourceType ());
				return attackMove (blue, red, minion, skills, shop, gold, play);
		}
		
		else if (play.equals("a")) {//attack opponent route 
			return attack (blue, red, minion, ability, skills, shop, gold);
		}
		
		else { //farm minions route
			return minionAttack (blue, red, minion, ability, skills, shop, gold);
		}
	}
	
	//minion attack move
	public static boolean minionAttack (Champion blue, Champion red, Champion minion, int ability, Abilities [][] skills, Item [][] shop, int gold) {
	
		//damage shield if it's higher than attack damage
		if (blue.getShield () >= skills [minion.getId()][0].adaptiveForce (minion, blue)) {
			skills [minion.getId()][0].attackSummoner (minion, blue, blue.getHealth (), blue.getShield ());
			
		}
		
		//damage health if attack could break shield or player have no shield
		else {
			skills [minion.getId()][0].attackSummoner (minion, blue, blue.getHealth (), blue.getShield ());
			blue.setShield(0);
			
		}
		
		//describe minion attack move
		System.out.println(minion.getName () + " casted " + skills [minion.getId()][0].getName () + " dealing " + skills [minion.getId()][0].adaptiveForce (minion, blue) + " damage!\n");
		
		return farm (blue, red, minion, ability, skills, shop, gold);
		
	}
	
	//player attack minion move
	public static boolean farm (Champion blue, Champion red, Champion minion, int ability, Abilities [][] skills, Item [][] shop, int gold) {
		
		//attack minion
		skills [blue.getId()][ability].attackSummoner (blue, minion, minion.getHealth (), minion.getShield ());
		
		//describe user attack move
		System.out.println(blue.getName () + " casted " + skills [blue.getId()][ability].getName () + " dealing " + skills [blue.getId()][ability].adaptiveForce (blue, minion) + " damage!\n");
		
		//drain resource according to ability cost
		blue.useResource (blue, skills[blue.getId()][ability].getAbilityCost ());
		
		//activate the ability cooldown timer
		skills [blue.getId()][ability].useAbility ();
		skills [blue.getId()][ability].abilityCooldown (skills [blue.getId()][ability].getId ());
		
		//earn 100 gold & gain 2 levels if defeat melee minion
		if (minion.getHealth () <= 0 && minion.getName ().equals("Caster Minion")) {
			gold = gold + 50;
			blue.levelUp (blue, 1);
			System.out.println ("\nMelee Minion Defeated! You earned " + 100 + " gold!\n");
		}
		
		//earn 50 gold & gain 1 levels if defeat caster minion
		else if (minion.getHealth () <= 0 && minion.getName ().equals("Melee Minion")) {
			gold = gold + 100;
			blue.levelUp (blue, 2);
			System.out.println ("\nCaster Minion Defeated! You earned " + 100 + " gold!\n");
		}
		
		//earn 250 gold & gain 3 levels if defeat cannon minion
		else if (minion.getHealth () <= 0 && minion.getName ().equals("Cannon Minion")) {
			gold = gold + 250;
			blue.levelUp (blue, 3);
			System.out.println ("\nCannon Minion Defeated! You earned " + 250 + " gold!\n");
		}
		
		//earn 500 gold & gain 4 levels if defeat turret minion
		else if (minion.getHealth () <= 0 && minion.getName ().equals("Turret Minion")) {
			gold = gold + 500;
			blue.levelUp (blue, 4);
			System.out.println ("\nTurret Struck Down! You earned " + 500 + " gold!\n");
		}
		
		//keep attacking until minion or player die
		else {
			attackMove (blue, red, minion, skills, shop, gold, "f");
		}
		
		//reduce every ability cooldown by 1 turn
		for (int i = 0; i < skills [blue.getId ()].length; i ++) {
			if (skills [blue.getId ()][i].getCooldown (skills [blue.getId ()][i].getId ()) != 0) {
				skills [blue.getId ()][i].reduceCooldown ();		
			}
		}
		
		//switch over to opponent turn
		return opponentTurn (blue, red, minion, skills, shop, gold);
	}
	
	//player attack opponent move
	public static boolean attack (Champion blue, Champion red, Champion minion, int ability, Abilities [][] skills, Item [][] shop, int gold) {
		
		//damage shield if it's higher than attack damage
		if (red.getShield () >= skills [blue.getId()][ability].adaptiveForce (blue, red)) {
			skills [blue.getId()][ability].attackSummoner (blue, red, red.getHealth (), red.getShield ());
		}
		
		//damage health if attack could break shield or player have no shield
		else {
			skills [blue.getId()][ability].attackSummoner (blue, red, red.getHealth (), red.getShield ());
			red.setShield (0); 
			
		}
		
		//reduce every ability cooldown by 1 turn
		for (int i = 0; i < skills [blue.getId ()].length; i ++) {
			if (skills [blue.getId ()][i].getCooldown (skills [blue.getId ()][i].getId ()) != 0) {
				skills [blue.getId ()][i].reduceCooldown ();		
			}
		}
		
		//drain resource according to ability cost
		blue.useResource (blue, skills[blue.getId()][ability].getAbilityCost ());
		
		//activate the ability cooldown timer
		skills [blue.getId()][ability].useAbility ();
		skills [blue.getId()][ability].abilityCooldown (skills [blue.getId()][ability].getId ());
		
		//describe attack move
		System.out.println(blue.getName () + " casted " + skills [blue.getId()][ability].getName () + " dealing " + skills [blue.getId()][ability].adaptiveForce (blue, red) + " damage!\n");
		
		//switch over to opponent turn
		return opponentTurn (blue, red, minion, skills, shop, gold);
	
	}
	
	//opponent turn move
	public static boolean opponentTurn (Champion blue, Champion red, Champion minion, Abilities [][] skills, Item [][] shop, int gold) {
		
		//ensure opponent is still alive
		if (red.getHealth () <= 0) {
			return arena (blue, red, skills, shop, gold);
		}
		
		//set tracking values
		int track = 4;
		
		//calculate power to health ratio of both champions
		int oppPower = (int)((skills[red.getId ()][0].adaptiveForce(red, blue)/red.getHealth ()) * 100);
		int userPower = (int)((skills[blue.getId ()][0].adaptiveForce(blue, red)/blue.getHealth ()) * 100);
		
		//attack when power level is higher & have at least 100 resource
		if (oppPower >= userPower && red.getResourceSupply () >= 100) {
			while (track > 0){ //ensure usage of 1 attack move
				
				//use strongest ability that is not on cooldown 
				if (red.getResourceSupply () >= skills[red.getId()][track].getAbilityCost () && skills [red.getId ()][track].getCooldown (skills [red.getId ()][track].getId ()) == 0) {
					
					//damage shield if it's higher than attack damage
					if (blue.getShield () > skills [red.getId()][track].adaptiveForce (red, blue)) {
						skills [red.getId()][track].attackSummoner (red, blue, blue.getHealth (), blue.getShield ());
					}
					
					else { //damage health if attack could break shield or player have no shield
						skills [red.getId()][track].attackSummoner (red, blue, blue.getHealth (), blue.getShield ());
						blue.setShield (0);
					}
					
					//describe opponent attack move
					System.out.println(red.getName () + " casted " + skills [red.getId()][track].getName () + " dealing " + skills [red.getId()][track].adaptiveForce (red, blue) + " damage!\n");
					
					//drain resource according to ability cost
					red.useResource(red, skills[red.getId()][track].getAbilityCost ());
					
					//activate the ability cooldown timer
					skills [red.getId()][track].useAbility ();
					skills [red.getId()][track].abilityCooldown (skills [blue.getId()][track].getId ());
					
					//exit loop after an attack move
					track = 0;
				}
				
				//move down the ability list 
				if (track > 0) {
					track--; 
				}
			}
		}
		
		else { //block when power level is lower or have less than 100 resource
			
			red.defend (red, skills [red.getId()][5]); //add shield
			
			//describe opponent block move
			System.out.println(red.getName () + " Defended! " + red.getName () + " gained: " + skills [red.getId()][5].getShield () + " Shield & " + red.getResourceSupply () + " " + red.getResourceType () + "\n");
		}
		
		//regenerate health for both if no one dies
		if (blue.getHealth () > 0) {
		
			//regenerate HP every turn 
			blue.regenHealth (blue);
			System.out.println(blue.getName () + " Regenerated: " + blue.getHealthRegen () + " HP\n");
				
			red.regenHealth (red);
			System.out.println(red.getName () + " Regenerated: " + red.getHealthRegen () + " HP\n");
		}
		
		return arena (blue, red, skills, shop, gold);
	}
	
	//display shop of items
	public static void showShop (Champion blue, Champion red, Abilities [][] skills, Item [][] shop, int gold) {
		
		//display gold owned
		System.out.println ("\nGold: " + gold + "\n");
		Scanner scanner = new Scanner (System.in);
		
		//display items in distinct categories
		for (int i = 0; i < shop.length ; i++) {
			
			if (i == 0) {
				System.out.println ("Tank: Build (0)");
			}
			else if (i == 1) {
				System.out.println ("\nAttack Damage: Build (1)");
			}
			else if (i == 2) {
				System.out.println ("\nAbility Power: Build (2)");
			}
			else {
				System.out.println ("\nResource: Build (3)");
			}
			
			for (int p = 0; p < shop[i].length; p++) {
				
				System.out.println("\t" + "(" + p + "). " + shop [i][p].getName() + ": " + shop [i][p].getPrice() + " G");
			}
		}
		
		//inspect or buy item options
		System.out.println ("\nInspect Item. ['i']\tBuy Item. ['b']");
		String market = scanner.nextLine ();
		
		//ensure valid input for inspection or purchase
		while (!market.equals("i") && !market.equals("b")) {
			System.out.print("Invalid Input!\tInspect Item. ['i']\tBuy Item. ['b']");
			market = scanner.nextLine();
		}
		
		//inspecting an item 
		if (market.equals ("i")) {
			
			System.out.print("Inspect Build: ");
			int build = scanner.nextInt (); //get specific item category
			
			//ensure valid build input
			while (build != 0 && build != 1 && build != 2 && build != 3) {
				System.out.println("Invalid Build Category!");
				build = scanner.nextInt ();
			}
			
			showItem (blue, red, skills, shop [build], shop, gold);
		}
		
		//buying an item
		else {
			
			System.out.print("Buy Item in Build: ");
			int buy = scanner.nextInt (); //get specific item category
			
			//ensure valid buy input 
			while (buy != 0 && buy != 1 && buy != 2 && buy != 3) {
				System.out.println("Invalid Build Category!");
				buy = scanner.nextInt ();
			}
			
			buyItem (blue, red, skills, shop [buy], shop, gold);
		}
		
	}
	
	//provide closer look into the item
	public static void showItem (Champion blue, Champion red, Abilities [][] skills, Item [] craft, Item [][] shop, int gold) {
		
		Scanner scanner = new Scanner (System.in);
		
		//display items in specified build category
		for (int i = 0; i < craft.length; i++) {
			System.out.println("\t" + "(" + i + "). " + craft [i].getName() + ": " + craft [i].getPrice() + " G");
		}
		
		System.out.println ("Inspect Item: ");
		int choice = scanner.nextInt ();
		
		//ensure valid item of inspection
		if (craft == shop [3]) { //category with only 2 items
			while (choice != 0 && choice != 1) {
				System.out.println("Invalid Item Option");
				choice = scanner.nextInt ();
			}
		}
		
		else { //category with only 5 items
			while (choice != 0 && choice != 1 && choice != 2 && choice != 3 && choice != 4) {
				System.out.println("Invalid Item Option");
				choice = scanner.nextInt ();
			}
		}
		
		System.out.println ("Stats Upgrade: ");
		
		//display potential tank stats upgrade
		if (craft [choice] == shop [0][choice]) {
			System.out.println ("(🖤). Health: " + blue.getHealth () + " + " + craft[choice].getHpUpgrade());
			System.out.println ("(💞). Health Regeneration: " + blue.getHealthRegen() + " + " + craft[choice].getHprUpgrade());
			System.out.println ("(🛡️). Shield: " + blue.getShield() + " + " + craft[choice].getSUpgrade());
			System.out.println ("(🎽). Armor: " + blue.getArmor() + " + " + craft[choice].getArUpgrade());
			System.out.println ("(👘). Magic Resist: " + blue.getMagicResist() + " + " + craft[choice].getMrUpgrade());
		}
		
		//display potential attack damage stats upgrade
		else if (craft [choice] == shop [1][choice]) {
			System.out.println ("(⚔️). Attack Damage: " + skills[blue.getId()][0].getAttackDamage() + " + " + craft[choice].getAdUpgrade());
			System.out.println ("(🎯). Crit Chance: " + blue.getCritChance() + " + " + craft[choice].getCUpgrade());
			System.out.println ("(💦). Life Steal: " + skills[blue.getId()][0].getLifeSteal () + " + " + craft[choice].getLsUpgrade());
		}
		
		//display potential ability power stats upgrade
		else if (craft [choice] == shop [2][choice]){
			System.out.println ("(🪄). Ability Power: " + skills[blue.getId()][0].getAbilityPower() + " + " + craft[choice].getApUpgrade());
			System.out.println (blue.displayResource() + " + " + craft[choice].getRUpgrade());
		}
		
		//display potential resource regen stats upgrade
		else {
			System.out.println (blue.displayResource() + " + " + craft[choice].getRUpgrade());
		}
		
		System.out.println("\nBuy Item. ['b']\tReturn to Shop. ['r']\tReturn to Play. ['p']");

		Scanner play = new Scanner (System.in);
		String decision = play.nextLine();
		
		//ensure valid player move
		while (!decision.equals("b") && !decision.equals("r") && !decision.equals("p")) {
			System.out.print("Invalid Input!\tBuy Item. ['b']\\tReturn to Shop. ['r']\\tReturn to Play. ['p']" );
			decision = play.nextLine();
		}
			
		if (decision.equals("b")) { //buy item 
			buyItem (blue, red, skills, craft, shop, gold);
		}
		
		else if (decision.equals("r")) { //return to shop
			showShop (blue, red, skills, shop, gold);
		}
		
		else { //return to play
			arena (blue, red, skills, shop, gold);
		}
		
	}
	
	//buy item & upgrade stats
	public static boolean buyItem (Champion blue, Champion red, Abilities [][] skills, Item [] build, Item [][] shop, int gold) {
		
		//display gold owned
		System.out.println ("\nGold: " + gold);
		Scanner scanner = new Scanner (System.in);
		
		//display items in specified build category
		for (int i = 0; i < build.length; i++) {
			System.out.println("\t" + "(" + i + "). " + build [i].getName() + ": " + build [i].getPrice() + " G");
		}
		
		System.out.println ("Buy Item: ");
		
		int choice = scanner.nextInt ();
		
		//ensure valid item of purchase
		if (build == shop [3]) { 
			while (choice != 0 && choice != 1) { //build with only 2 item options
				System.out.println("Invalid Item Option");
				choice = scanner.nextInt ();
			}
		}
		
		else { //build with 5 item options
			while (choice != 0 && choice != 1 && choice != 2 && choice != 3 && choice != 4) {
				System.out.println("Invalid Item Option");
				choice = scanner.nextInt ();
			}
		}
		
		//upgrade tank stats according to items upgrade
		if (gold >= build [choice].getPrice () && build [choice] == shop [0][choice]) {
			
			gold = gold - build [choice].getPrice (); //reduce gold based on item price
			
			blue.hpUpgrade (blue, build [choice]); //upgrade health
			blue.hprUpgrade (blue, build [choice]); //upgrade health regen
			blue.sUpgrade (blue, build [choice]); //upgrade shield
			blue.arUpgrade (blue, build [choice]); //upgrade armor
			blue.mrUpgrade (blue, build [choice]); //upgrade magic resist
			
		}
		
		//upgrade attack damage stats according to items upgrade
		else if (gold >= build [choice].getPrice () && build [choice] == shop [1][choice]) {
			
			gold = gold - build [choice].getPrice (); //reduce gold based on item price
			
			skills[blue.getId()][0].adUpgrade (skills[blue.getId()][0], build [choice]); //upgrade attack damage
			blue.cUpgrade (blue, build [choice]); //upgrade crit chance
			skills[blue.getId()][0].lsUpgrade (skills[blue.getId()][0], build [choice]); //upgrade life steal
		}
		
		//upgrade ability power stats according to items upgrade
		else if (gold >= build [choice].getPrice () && build [choice] == shop [2][choice]) {
			
			gold = gold - build [choice].getPrice (); //reduce gold based on item price
			
			skills[blue.getId()][0].apUpgrade (skills[blue.getId()][0], build [choice]); //upgrade ability power
			blue.rUpgrade (blue, build [choice]); //upgrade resource regen
		}
		
		//upgrade ability power stats according to items upgrade
		else if (gold >= build [choice].getPrice () && build [choice] == shop [3][choice]) {
					
				gold = gold - build [choice].getPrice (); //reduce gold based on item price
				blue.rUpgrade (blue, build [choice]); //upgrade resource regen
		}
		
		else {//ensure sufficient gold 
			System.out.println ("Insufficient Gold!\tGold: " + gold + "\tCost: " + build [choice].getPrice () + "\n");
		}
		
		return arena (blue, red, skills, shop, gold); //return to play
		
	}
}
