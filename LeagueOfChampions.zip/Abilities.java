public class Abilities {
	
	//declaration of characteristics in an abilities
	private String name;
	private int identification;
	private int abilityCost;
	private int heal;
	private int shield;
	private int attackDamage;
	private double crit;
	private double lifeSteal;
	private int abilityPower;
	private int cooldown;
	private boolean cooldownStatus;
	private String trait;
	
	//initialize the attributes of abilities (e.g., damage, healing, etc.)
	public Abilities (String n, int id, int ac, int h, int s, int at, double c, double ls, int ap, int cd, boolean cs, String t) {
		
		this.name = n; 
		this.identification = id;
		this.abilityCost = ac;
		this.heal = h;
		this.shield = s;
		this.attackDamage = at; 
		this.crit = c;
		this.lifeSteal = ls;
		this.abilityPower = ap;
		this.cooldown = cd;
		this.cooldownStatus = cs;
		this.trait = t;
		
	}
	
	//get name of ability
	public String getName () {
		
		return this.name;
	}
	
	//get unique id of ability
	public int getId () {
		
		return this.identification;
	}
	
	//get the cost of ability
	public int getAbilityCost () {
		
		return this.abilityCost;
	}
	
	//get healing of ability
	public int getHeal () {
		
		return this.heal;
	}
	
	//get shield of ability
	public int getShield () {
		
		return this.shield;
	}
	
	//get attack damage of ability
	public int getAttackDamage () {
		
		return this.attackDamage;
	}
	
	//update attack damage of ability
	public void setAttackDamage (int ad) {
			
		this.attackDamage = ad;
	}
	
	//upgrade attack damage of ability according to item
	public void adUpgrade (Abilities skill, Item upgrade) {

		System.out.println ("(⚔️). Attack Damage: " + this.attackDamage + " + " + upgrade.getAdUpgrade ());
		
		skill.setAttackDamage (this.attackDamage + upgrade.getAdUpgrade ());
			
	}
	
	//get ability power of ability
	public int getAbilityPower () {
		
		return this.abilityPower;
	}
	
	//update ability power of ability
	public void setAbilityPower (int ap) {
				
		this.abilityPower = ap;
	}
	
	//upgrade ability power of ability according to item
	public void apUpgrade (Abilities skill, Item upgrade) {
		
		System.out.println ("(🪄). Ability Power: " + this.abilityPower + " + " + upgrade.getApUpgrade ());
		
		skill.setAbilityPower (this.abilityPower + upgrade.getApUpgrade ());
				
	}
	
	//get crit damage of ability
	public double getCrit () {
		
		return this.crit; 
	}
	
	//get life steal percentage of ability
	public double getLifeSteal () {
		
		return this.lifeSteal; 
	}
	
	//update life steal of ability
	public void setLifeSteal (double ls) {
					
		this.lifeSteal = ls;
	}
	
	//upgrade life steal of ability according to item
	public void lsUpgrade (Abilities skill, Item upgrade) {
		
		System.out.println ("(💦). Life Steal: " + this.lifeSteal + " + " + upgrade.getLsUpgrade ());
		
		skill.setLifeSteal (this.lifeSteal + upgrade.getLsUpgrade ());
					
	}
	
	//get the stolen health of opponent after life steal
	public int stealLife (int opponentHp) {
		
		int stolenHealth = (int)(opponentHp * this.lifeSteal);
		
		return stolenHealth;
		
	}
	
	//determine if the ability is on cooldown or available
	public int getCooldown (int ability) {
	
		if (this.cooldownStatus == true) { //ability on cooldown
			return this.cooldown; 
		}
		
		return 0;
	}
	
	//set the ability on cooldown
	public boolean useAbility () { 
		
		return this.cooldownStatus = true;

	}
	
	//apply cooldown timer depending on ability
	public int abilityCooldown (int ability) {
			
		if (ability == 0) { //no cooldown for auto attack
			this.cooldown = 0;
		}
			
		else if (ability == 1) {//1 turn cooldown for 1st ability
			this.cooldown = 1;
		}
			
		else if (ability == 2) {//2 turn cooldown for 2nd ability
			this.cooldown = 2;
		}
			
		else if (ability == 3) {//3 turn cooldown for 3rd ability
			this.cooldown = 3;
		}
			
		else {//4 turn cooldown for ultimate ability
			this.cooldown = 4;
		}
			
		return this.cooldown;
	}
		
	//reduce cooldown of ability by 1 turn
	public int reduceCooldown () {
		
		return this.cooldown = this.cooldown - 1; 
	}
	
	//get ability type (auto attack, 1st ability, 2nd ability, 3rd ability, ultimate, block)
	public String getTrait () {
		
		return this.trait; 
	}
	
	//calculate total damage after all resistances
	public int adaptiveForce (Champion summoner, Champion opponent) {
		
		//generate number between 0-100
		double luck = (int) Math.random () * 101;
		
		//set initial adaptive force before resistances
		int totalAttackDamage = this.attackDamage;
		int totalAbilityPower = this.abilityPower;
		
		// if number is less than crit chance; it's a critical hit
		if (luck < summoner.getCritChance ()) {
			
			//attack damage after armor is applied
			totalAttackDamage = (int)(this.attackDamage * (100.0 / (100 + opponent.getArmor ())) * this.crit);
		
			//ability power after magic resist is applied
			totalAbilityPower = (int)(this.abilityPower * (100.0 / (100 + opponent.getMagicResist ())) * this.crit);
		
		}
		
		//no critical hit
		else {
			//attack damage after armor is applied
			totalAttackDamage = (int)(this.attackDamage * (100.0 / (100 + opponent.getArmor ())));
		
			//ability power after magic resist is applied
			totalAbilityPower = (int)(this.abilityPower * (100.0 / (100 + opponent.getMagicResist ())));
			
		}
		
		//total damage after attack damage & ability power & scaling is applied
		return totalAttackDamage + (int)(totalAbilityPower * summoner.getBaseScale ());
		
	}
	
	//attack opponent health and/or shield
	public void attackSummoner (Champion summoner, Champion opponent, int opponentHp, int opponentShield) {
		
		//store initial damage before shield
		int damage = adaptiveForce (summoner, opponent);
		
		//steal opponent health if ability have life steal
		if (this.lifeSteal > 0) {
			summoner.stealLife(summoner, stealLife (opponentHp));
		}
		
		//damage the shield but not fully broken
		if (opponentShield >= damage) {
			opponent.takeDamage(opponent, damage, 1); //update champion shield 	
		}
		
		//break the shield & damage opponent health
		else if (opponentShield < damage && opponentShield > 0) {
			damage = damage - opponentShield; //get damage residue after breaking the shield
			opponent.takeDamage (opponent, damage, 2); //update champion shield & health
		}	
		
		else { //damage opponent health directly
			opponent.takeDamage (opponent, damage, 3); //update champion health
		}
	}
	
}
